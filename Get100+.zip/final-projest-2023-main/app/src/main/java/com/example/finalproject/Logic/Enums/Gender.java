package com.example.finalproject.Logic.Enums;

public enum Gender {
    Male, Female;
}
