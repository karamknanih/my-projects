package com.example.finalproject.Logic.Enums;

public class Subject {
    private String name;
}
