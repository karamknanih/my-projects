package com.example.finalproject.Logic.Enums;

public enum Type {
    Teacher, Student, Admin
}
