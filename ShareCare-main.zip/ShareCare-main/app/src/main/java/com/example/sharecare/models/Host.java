package com.example.sharecare.models;

public class Host extends Parent {


    public Host(String username, String phoneNumber, String email, String address, String password, int numberOfKids, String maritalStatus, String gender, String language, String religion) {
        super(username, phoneNumber, email, address, password, numberOfKids, maritalStatus, gender, language, religion);
    }
}
