package com.example.sharecare.valdiators;

public class Validator {
    public static boolean isFieldEmpty(String field) {
        return field.trim().isEmpty();
    }
}
