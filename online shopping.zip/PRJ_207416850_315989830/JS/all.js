// two variables to save the product ID to be deleted of a specific list.
let pToDelete = -1;
let lToDelete = -1;
let removed = 0;
let listtocreate1 = 0;
const productsNames = [];
const btnPurchasedtxt = `<td class="purchase" id="purchase">✔</td>
<td>
<button type="submit" class="btnPurchase btn btn-outline-warning">Unpurchase</button>
<button type="submit" class="btnRemove btn btn-outline-danger" hidden>Remove</button></td>`;
const btnUnPurchasedtxt = `<td class="purchase" id="purchase">✖</td>
<td>
<button type="submit" class="btnPurchase btn btn-outline-success">Purchase</button>
<button type="submit" class="btnRemove btn btn-outline-danger">Remove</button></td>`;


const btnPurchasedtxt1 = `<button type="submit" class="btnPurchase btn btn-outline-warning">Unpurchase</button>
<button type="submit" class="btnRemove btn btn-outline-danger" hidden>Remove</button>`;
const btnUnPurchasedtxt2 = `<button type="submit" class="btnPurchase btn btn-outline-success">Purchase</button>
<button type="submit" class="btnRemove btn btn-outline-danger">Remove</button>`;

let TotalLists = new Vue({
    el: '#total',
    data: {
        totallists: 0
    }
})

let CurrentList = new Vue({
    el: '#current',
    data: {
        current: 0
    }
})

let table = new Vue({
    el: '#Table',
    data: {
        ID: 0,
        Name : "",
        Quantity : "",
        Purchase1 : "",
        Purchase2 : null,
        rows:[]
    },
    methods:{
        addRow(ID1, Name1, Quantity1, Purchase11, Purchase22){
          var my_object = {
            ID: ID1,
            Name: Name1,
            Quantity: Quantity1,
            Purchase1: Purchase11,
            Purchase2: Purchase22,
          };
          this.rows.push(my_object);

          this.ID = 0;
          this.Name = "";
          this.Quantity = "";
          Purchase1 = "";
          Purchase2 = null;
        },
        removeRow(ID){
            for (let i = 0; i < this.rows.length; i++) {
                if(this.rows[i].ID == ID){
                    this.rows.splice(i, 1);
                    return;
                }
            }
          }
      }
});

$(document).ready(function (){
    //two constants describe the buttons design whenever the product purchased or not..
    
    $("#name").autocomplete({
       source: productsNames
    });
    
    $(document).on('click', '#addproductbtn', function () {
        $('.modal.addp').fadeIn( function() {
            $('.modal.addp').modal('show');
        });
    });


    $(document).on('click', '#pdelete', function () {
        let productID = pToDelete;
        let listID = parseInt($('#current').text());
        let rowToRemove;

        table.removeRow(productID);

        $.ajax({
            url:"./api/removeproduct.php",
            type:"POST",
            data:({ProductID:productID, TableID:listID}),
            success:function(response){
                pToDelete = -1;
                refreshautocomplete(); 
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });

        $('.modal.remove').fadeOut( function() {
            $('.modal.remove').modal('hide');
        });
    });
    $(document).on('click', '#pcancel', function () {
        $('.modal.remove').fadeOut( function() {
            $('.modal.remove').modal('hide');
        });
        pToDelete = -1;
    });

    $(document).on('click', '.btnRemove', function () {
        $('.modal.remove').fadeIn( function() {
            $('.modal.remove').modal('show');
        });
        pToDelete = $(this).parents("tr").attr('data-id');
        pName = $(this).parents("tr").find(".name").text();
        listNum = $('#current').text();
        $('.mbody').html("You are about to delete <b>"+ pName + "</b> from your list (" + listNum +")");
    })

    $(document).on('click', '.btnPurchase', function () {
        let productID = parseInt($(this).parents("tr").data("id"));
        let tableid = parseInt($('#current').text());
        let purchase = 0;
        if($(this).text() === "Purchase")
            purchase = 1;

        $.ajax({
            url:"./api/purchase.php",
            type:"POST",
            data:({Purchase:purchase, ProductID:productID, TableID:tableid}),
            success:function(response){
                showList(tableid);
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });
    })

    $("form#addProduct").submit(function (e) {
        e.preventDefault();
        let name = $("#name").val();
        let tableid = parseInt($("#current").text());
        let quantity = parseInt($("#quantity").val());
        if(parseInt(quantity) < 0){
            quantity = 0;
        }

        $.ajax({
            url:"./api/addproduct.php",
            type:"POST",
            data:({tableid:tableid, name:name, quantity:quantity}),
            success:function(response){
                refreshautocomplete();
                showList(tableid);
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        })

        $(this).find("input").val("");
        $("#name").focus();
    })
    

    $(document).on('click', '.createlist', function () {
        $('#createlistmodal').fadeIn( function() {
            $('#createlistmodal').modal('show');
        });
    });

    $(document).on('click', '.dropdown-item.listtocreate', function () {
        let listname = $(this).text();
        listtocreate1 = $(this).data("id");
        $('#listsToCopy').text(listname);
    });

    $(document).on('click', '#createlistsuccess', function () {
        event.preventDefault();
        $('#createlistmodal').fadeOut( function() {
            $('#createlistmodal').modal('hide');
        });
        $.ajax({
            url: "./api/getlists.php",
            type:"GET",
            success: function(data) {
                let listCount = data.length + 1;
                TotalLists.totallists = listCount + 1;
                // $('#total').html(listCount + 1);
                $.ajax({
                    url:"./api/addlist.php",
                    type:"POST",
                    data:({list:listCount}),
                    success:function(response){
                        if(listtocreate1 > 0){
                            $.ajax({
                                url: "./api/getproducts.php?List="+listtocreate1,
                                type:"GET",
                                success: function(data) {
                                    let productCount = data.length;
                                    let i = 0;
                                    let productsAdded = 0;
                                    for(i ; i < productCount ; i+=1){
                                        j = true;
                                        $.ajax({
                                            url:"./api/addproduct.php",
                                            type:"POST",
                                            data:({tableid:listCount, name:data[i]['Name'], quantity:data[i]['Quantity'],purchased:data[i]['IsPurchased']}),
                                            success:function(response){
                                                productsAdded += 1;
                                                if(productsAdded == productCount){
                                                    loadlists();
                                                }
                                            },
                                            error:function(xhr,status,error)  {
                                                console.log(error);
                                            }
                                        });
                                    }
                                }
                            });   
                        }else{
                            loadlists();
                            $('#createlistmodal').fadeOut( function() {
                                $('#createlistmodal').modal('hide');
                            });
                        }
                    },
                    error:function(xhr,status,error)  {
                        console.log(error);
                    }
                })
            }
        });
    });


    $(document).on('click', '.dropdown-item.listtoshow', function () {
        showList($(this).data("id"));
    });

    function loadlists(){
        $.ajax({
            url: "./api/getlists.php",
            type:"GET",
            success: function(data) {
                let listCount = data.length;
                TotalLists.totallists = listCount;
                // $('#total').html(listCount);
                $('#spinner').remove();
                if(listCount == 0){    
                    let warn = `<div class="alert alert-danger" id="pralert" role="alert">
                                    There are no lists. Click on "Create" Button below in order to create a new purchase list!
                                </div>`;

                    warn.innerHTML = `There are no lists. Click on "Create" Button below in order to create a new purchase list!`
                    $('#allLists').append(warn);
                    $('#addproduct').attr("disabled", true);
                    $('#lists').attr("disabled", true);
                    $('table').attr("hidden", true);
                }else{
                    $('#pralert').remove();
                    $('#addproduct').attr("disabled", false);
                    $('#lists').attr("disabled", false);
                    $('table').attr("hidden", false);
                    loadProducts();
                }
                $('#droplistcreate').html("");
                $('#drop').html("");
                let p = 0;
                do{
                    let listnum = p == 0 ? "Empty List" : "List " + p
                    let listdataid = p == 0 ? 0 : data[p-1]['ListID'];
                    let drop = `<a class="dropdown-item listtocreate" data-id=${listdataid}>${listnum}</a>`
                    $('#droplistcreate').append(drop);
                    if(p > 0){
                        let drop = `<a class="dropdown-item listtoshow" data-id=${listdataid}>${listnum}</a>`
                        $('#drop').append(drop);
                    }
                    p += 1;
                }while(p <= listCount);
                if(p > 1)
                    showList(data[p-2]['ListID']);
            }
        });
    }

    function loadProducts(listid){
        table.rows = [];
        $('table').children('tbody').html('');
        $.ajax({
            url: "./api/getproducts.php?List="+listid,
            type:"GET",
            success: function(data) {
                let productCount = data.length;
                let i = 0;
                while(i < productCount){
                    let quantity = data[i]['Quantity'] == 0 ? "" : data[i]['Quantity'];
                    if(parseInt(data[i]['IsPurchased'])){
                        let tr = `<tr data-id="${data[i]['ID']}">
                        <td class="name" id="fname">${data[i]['Name']}</td>
                        <td class="quantity" id="quantity">${quantity}</td>
                        ${btnPurchasedtxt}
                        </tr>`;
                        // $('table').children("tbody").append(tr);
                        table.addRow(data[i]['ID'],data[i]['Name'],  quantity , "✔", btnPurchasedtxt1);
                    }else {
                        let tr = `<tr data-id="${data[i]['ID']}">
                        <td class="name" id="fname">${data[i]['Name']}</td>
                        <td class="quantity" id="quantity">${quantity}</td>
                        ${btnUnPurchasedtxt}
                        </tr>`;

                        table.addRow(data[i]['ID'],data[i]['Name'],  quantity , "✖", btnUnPurchasedtxt2);
                        // $('table').children("tbody").append(tr);
                    }
                    i += 1;
                }
            }
        });
    }

    function showList(listid){
        $('#lists').html("List " + listid);
        $('table').children("tbody").html('');
        CurrentList.current = listid;
        // $('#current').html(listid);
        loadProducts(listid);
    }

    function refreshautocomplete(){
        $.ajax(
            {
                url:"./api/getproducts.php?autocomplete=1",
                type:"GET",
                success: function(data) {
                    productsNames.splice(0,productsNames.length);
                    $(data).each(function(index,value){
                        if(!productsNames.includes(value['Name']))
                            productsNames.push(value['Name']);
                    });
                }
            });
    }

    refreshautocomplete();
    loadlists();
    window.scrollTo(0, 0);
});