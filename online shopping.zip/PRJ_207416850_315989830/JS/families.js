$(document).ready(function (){

    $(document).on('click', '#creatfamily', function(){
        event.preventDefault();
        $('.modal.createfamily').fadeIn(function(){
            $('.modal.createfamily').modal('show');
        });
    });

    $.ajax({
        url: "./api/getallfamilies.php",
        type:"GET",
        success: function(data) {
            familiescount = data.length;
            rows = Math.ceil(data.length/2);
            $(".allFamilies").html("");
            createfamilyRows(rows)
            i = 0;
            let application = 0;
            while(i < familiescount){
                if(parseInt(data[i]['Applied']))
                    application = 1
                i++;
            }
            i = 0;
            while(i < familiescount ){
                addfamily(data[i]['FamilyID'], data[i]['FamilyName'], data[i]['Description'], Math.ceil((i+1)/2), parseInt(data[i]['Applied']), application, parseInt(data[i]['isMember']))
                i++;
            }
        }
    });

    function addfamily(familyID, familyName, Description, rownum, applied, hasapplication, isMember){
        rowElement = null;
        $( ".allFamilies" ).children('.row').each(function( index ) {
            if($(this).data('id') == rownum)
                rowElement = $(this);
        });
        let tr = ``;
        if(isMember){
            tr = `<div class="col-md-6 col-12">
                        <div class="card" data-id=${familyID}>
                            <div class="card-header">
                                ${familyName}
                            </div>
                            <div class="card-body">
                                <p class="card-text"><b>Description:</b> <br>${Description}</p>
                            </div>
                            <div class="card-footer">
                                <button type="button" href="#" class="btn btn-outline-dark" disabled>Already a Member</button>
                            </div>
                       </div>
                    </div>`
        }
        else if(!hasapplication){
            tr = `<div class="col-md-6 col-12">
                        <div class="card" data-id=${familyID}>
                            <div class="card-header">
                                ${familyName}
                            </div>
                            <div class="card-body">
                                <p class="card-text"><b>Description:</b> <br>${Description}</p>
                            </div>
                            <div class="card-footer">
                                <button type="button" href="#" class="btn btn-outline-dark applybtn">Apply</button>
                            </div>
                       </div>
                    </div>`
        }else{
            if(applied)
            tr = `<div class="col-md-6 col-12">
                        <div class="card" data-id=${familyID}>
                            <div class="card-header">
                                ${familyName}
                            </div>
                            <div class="card-body">
                                <p class="card-text"><b>Description:</b> <br>${Description}</p>
                            </div>
                            <div class="card-footer">
                                <button type="button" href="#" class="btn btn-outline-dark" disabled >Applied</button>
                                <button type="button" href="#" class="btn btn-danger unapply" >Un-Apply</button>
                            </div>
                       </div>
                    </div>`
            else{
                tr = `<div class="col-md-6 col-12">
                            <div class="card" data-id=${familyID}>
                                <div class="card-header">
                                    ${familyName}
                                </div>
                                <div class="card-body">
                                    <p class="card-text"><b>Description:</b> <br>${Description}</p>
                                </div>
                                <div class="card-footer">
                                    <button type="button" href="#" class="btn btn-outline-dark applybtn" >Apply</button>
                                </div>
                        </div>
                        </div>`
            }
        }
        rowElement.append(tr);
    }


    function createfamilyRows(rownum){
        i = 1;
        while(i <= rownum){
            let tr = `<div class="row" data-id=${i}>`
            $(".allFamilies").append(tr);
            i++;
        }
    }

    $(document).on('click', '.applybtn', function(){
        event.preventDefault();
        let familyID = $(this).parents('.card').data('id');
        let element = $(this);
        $.ajax({
            url:"./api/apply.php",
            type:"POST",
            data:({FamilyID:familyID}),
            success:function(response){
                reloadfamilies();
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });
    });

    $(document).on('click', '.unapply', function(){
        event.preventDefault();
        let familyID = $(this).parents('.card').data('id');
        let element = $(this);
        $.ajax({
            url:"./api/unapply.php",
            type:"POST",
            data:({Family:familyID}),
            success:function(response){
                reloadfamilies();
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });
    });


    $(document).on('click', '#createbtn', function () {
        event.preventDefault()
        let familyName = $("#familyName").val();
        let description = $("#familyDescription").val();
        createFamily(familyName,description);
    });

    function reloadfamilies(){
        $.ajax({
            url: "./api/getallfamilies.php",
            type:"GET",
            success: function(data) {
                familiescount = data.length;
                rows = Math.ceil(data.length/2);
                $(".allFamilies").html("");
                createfamilyRows(rows)
                i = 0;
                let application = 0;
                while(i < familiescount){
                    if(parseInt(data[i]['Applied']))
                        application = 1
                    i++;
                }
                i = 0;
                while(i < familiescount ){
                    addfamily(data[i]['FamilyID'], data[i]['FamilyName'], data[i]['Description'], Math.ceil((i+1)/2), parseInt(data[i]['Applied']),application, parseInt(data[i]['isMember']))
                    i++;
                }
            }
        });
    }


    function createFamily(familyName,description) {

        $.ajax({
            url:"./api/addfamily.php",
            type:"POST",
            data:({FamilyName:familyName, Description:description}),
            success:function(response){
                console.log(response)
                window.location.href = "./managefamily.php";
                
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });
    }

});