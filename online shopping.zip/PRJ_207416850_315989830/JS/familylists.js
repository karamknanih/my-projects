productToRemove = -1;
const productsNames = [];


let FamilyDetails = new Vue({
    el: '#familyDetails',
    data: {
        name: "",
        joinDate: ""
    }
})

let Families = new Vue({
    el: '#familiess',
    data: {
        familyName: []
    },
    methods:{
        addFamily(Namee){
            this.familyName.push(Namee);
        }
    }
})

let FamilyDeletion = new Vue({
    el: '#familydeletionbody',
    data: {
        familyDeletion: ""
    }
})

$(document).ready(function (){
    const btnPurchasedtxt = `<td class="purchase" id="purchase">✔</td>
    <td>
    <button type="submit" class="btnPurchase btn btn-outline-warning">Unpurchase</button>
    <button type="submit" class="btnRemove btn btn-outline-danger" hidden>Remove</button></td>`;
    const btnUnPurchasedtxt = `<td class="purchase" id="purchase">✖</td>
    <td>
    <button type="submit" class="btnPurchase btn btn-outline-success">Purchase</button>
    <button type="submit" class="btnRemove btn btn-outline-danger">Remove</button></td>`;

    $("#name").autocomplete({
        source: productsNames
     });

    $(document).on('click', '#addproduct', function(){
        event.preventDefault();
        $('.modal.addproduct').fadeIn(function(){
            $('.modal.addproduct').modal('show');
        });
    });

    $(document).on('click', '#submitadding', function(){
        event.preventDefault();
        let productName = $('#name').val();
        let Quantity = $('#quantity').val() == "" ? 0 : parseInt($('#quantity').val());
        let family = $('.family:selected').data('id')

        $.ajax({
            url:"./api/addfamilyproduct.php",
            type:"POST",
            data:({name:productName, quantity:Quantity,Family:family}),
            success:function(response){
                loadproducts(family);
                refreshautocomplete();
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        })

    });

    $(document).on('click', '.btnPurchase', function(){
        event.preventDefault();
        let ProductID = $(this).parents('tr').data('id');
        let purchase = $(this).html() == 'Purchase' ? 1 : 0;
        let family = $('.family:selected').data('id')


        $.ajax({
            url:"./api/familypurchase.php",
            type:"POST",
            data:({ProductID:ProductID, Purchase:purchase,Family:family}),
            success:function(response){
                loadproducts(family);
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        })
    });


    $(document).on('click', '.btnRemove', function(){
        event.preventDefault();
        productToRemove = $(this).parents('tr').data('id');
        let pproductName = $(this).parents('tr').children('#fname').html();
        $('.mbody').html("You are about to delete - <b>" + pproductName + "</b> - from your list");
        $('.modal.remove').fadeIn(function(){
            $('.modal.remove').modal('show');
        });
    });

    $(document).on('click', '#pdelete', function(){
        event.preventDefault();
        let family = $('.family:selected').data('id')

        $('.modal.remove').fadeOut(function(){
            $('.modal.remove').modal('hide');
        });
        $('tbody tr').each(function(){
            if($(this).data('id') == productToRemove){
                $(this).fadeOut(function(){
                    $(this).remove();
                });
            }
        });

        $.ajax({
            url:"./api/removefamilyproduct.php",
            type:"POST",
            data:({Family:family,ProductID:productToRemove}),
            success:function(response){
                refreshautocomplete();
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        })
    });

    $(document).on('click', '#quitfamily', function(){
        event.preventDefault();
        FamilyDeletion.familyDeletion = $('.family:selected').val();
        $('.modal.quitfamily').fadeIn(function(){
            $('.modal.quitfamily').modal('show');
        });
    });

    $(document).on('click', '#pQuit', function(){
        event.preventDefault();
        let family = $('.family:selected').data('id');
        
        $.ajax({
            url:"./api/removeMember.php",
            type:"POST",
            data:({FamilyID:family}),
            success:function(response){
                getFamilies();
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        })

        $('.modal.quitfamily').fadeOut(function(){
            $('.modal.quitfamily').modal('hide');
        });
    });

    $(document).on('click', '#familiess', function(){
        let familyID = $(this).children('.family:selected').data('id');
        loadproducts(familyID);
    });


    function loadproducts(familyID){
        $.ajax({
            url: "./api/getfamilyproducts.php?family=" + familyID,
            type:"GET",
            success: function(data) {
                productCount = data.length;
                $('.familyproducts').children('tbody').html('');
                if(productCount == 0)
                    return;
                let tr = ``;
                let i = 0;
                for(i; i < productCount ; i++){
                    let quantity = parseInt(data[i]['Quantity']) == 0 ? "" : parseInt(data[i]['Quantity']);
                    if(parseInt(data[i]['IsPurchased'])){
                        tr = `<tr data-id=${data[i]['ID']}>
                                <td class="name" id="fname">${data[i]['Name']}</td>
                                <td class="quantity" id="quantity">${quantity}</td>
                                ${btnPurchasedtxt}
                            </tr>`;
                    }else{
                        tr = `<tr data-id=${data[i]['ID']}>
                                <td class="name" id="fname">${data[i]['Name']}</td>
                                <td class="quantity" id="quantity">${quantity}</td>
                                ${btnUnPurchasedtxt}
                            </tr>`;
                    }
                    $('.familyproducts').children('tbody').append(tr);
                }
                FamilyDetails.joinDate = data[0]['JoinDate'];
            }
        });
        isManager(familyID);
    }

    function getFamilies(){
        $('#familiess').html("");
        $.ajax({
            url: "./api/getuserfamily.php",
            type:"GET",
            success: function(data) {
                if(data.length == 0)
                    window.location.href = "allfamilies.php";
                let i = 0;

                for(i; i< data.length; i++){
                    
                    $('#familiess').append(`<option class="family" data-id=${data[i]['FamilyID']}> ${data[i]['FamilyName']} </option>`);
                }
                
                loadproducts(data[0]['FamilyID'])
                
                FamilyDetails.joinDate = data[0]['JoinDate'];

                // FamilyDetails.name = data[0]['FamilyName'];

                // $('.fname').html(data[0]['FamilyName']);
                // $('.joinDate').html('<b>Join Date:</b> '  + data[0]['JoinDate']);
            }
        });
    }

    function refreshautocomplete(){
        $.ajax(
        {
            url:"./api/getfamilyproducts.php",
            type:"GET",
            success: function(data) {
                productsNames.splice(0,productsNames.length);
                $(data).each(function(index,value){
                    if(!productsNames.includes(value['Name']))
                        productsNames.push(value['Name']);
                });
            }
        });
    }

    function isManager(familyID){
        $.ajax(
        {
            url:"./api/getfamilybymanager.php?family="+familyID,
            type:"GET",
            success: function(data) {
                $('.quitfam').html('');
                if(data.length == 0){
                    $('.quitfam').html("<button type='button' class='btn btn-danger' id='quitfamily'>Quit Family</button>")
                }
            }
        });
    }

    refreshautocomplete();

    getFamilies()
});