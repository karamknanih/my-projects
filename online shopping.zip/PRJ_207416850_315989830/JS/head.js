$(document).ready(function (){
    $.ajax({
        url: "./api/getuserfamily.php",
        type:"GET",
        success: function(data1) {
            $.ajax({
                url: "./api/isManager.php",
                type:"GET",
                success: function(data2) {
                    let element = ``;

                    if(data1.length > 0){
                        if(data2[0]['FamilyID'] == null){
                            element = `<li class="nav-item">
                                    <a class="nav-link nv" href="familylists.php">Family Lists</a>
                            </li>`;
                            element = `<li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    My Family
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="familylists.php">Family Lists</a>
                                    </div>
                                </li>`;
                        }else{
                            element = `<li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    My Family
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="familylists.php">Family Lists</a>
                                    <a class="dropdown-item" href="managefamily.php">Manage Family</a>
                                    </div>
                                </li>`;
                        }
                    }
                    $('.familiess').append(element);     
                }
            });
        }
    });

    $(document).on('click', '#theme', function () {
        let theme = 'Light';
        
        if($(this)[0].checked){
            $('html').attr('data-theme','Dark');
            theme = 'Dark';
        }else{
            $('html').attr('data-theme','Light');
        }

        console.log(theme);
        $.ajax({
            url:"./theme.php",
            type:"POST",
            data:({Theme:theme}),
            success:function(response){
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });
    });


});