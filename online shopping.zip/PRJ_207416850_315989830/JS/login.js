email = "";

function loading(Email){
    email = Email;
}


$(document).ready(function (){
    // Password Validations
    $(document).on('click', '#passbtn', function () {
        let e1 = $('#password').val();
        let e2 = $('#rpassword').val();
        if(e1 !== e2 && e1.length >= 5 && e2.length >= 5){
            event.preventDefault();
            $('#rpassword').focus();
            alrt.innerText = "The entered Password does not match the repeated Password.";
        }
    })

    $(document).on('change keyup', '.password', function () {
        if($('#password').val().length > 4){
            if($('#rpassword').val() === $('#password').val()){
                document.querySelector("input#rpassword").setCustomValidity("");
            }else{
                document.querySelector("input#rpassword").setCustomValidity("Passwords Do not match");
            }
        }
        else{
            document.querySelector("input#rpassword").setCustomValidity("Passwords Do not match");
        }
    })
    $(document).on('change keyup', '.rpassword', function () {
        if($('#password').val().length <= 4){
            document.querySelector("input#rpassword").setCustomValidity("Passwords Do not match");
        }
        else if($('#rpassword').val() === $('#password').val()){
            document.querySelector("input#rpassword").setCustomValidity("");
        }
        else if($('#rpassword').val() !== $('#password').val()){
            document.querySelector("input#rpassword").setCustomValidity("Passwords Do not match");
        }
    })

    // Register Validations
    $(document).on('click', '#registerbtn', function () {
        let e1 = $("input#email").val().toLowerCase();
        let e2 = $("input#remail").val().toLowerCase();
        if(e1 !== e2 || e1 === "" || e2 === ""){
            event.preventDefault();
            let alrt = document.getElementById("ralert");
            alrt.removeAttribute("hidden");
            let alrt2 = document.getElementById("realert");
            alrt2.setAttribute("hidden","");
            if(e1 === "" || e2 === ""){
                alrt.innerText = "The entered email does not match the repeated email.";
                document.querySelector("input#email").focus();
            }
            else{
                alrt.innerText = "The entered email does not match the repeated email.";
                document.querySelector("input#remail").focus();
            }
        }
    })



    $(document).on('change keyup', '#email', function () {
        let e1 = $("#email");
        let e2 = $("#remail");
        if(e1.val().toLowerCase() !== e2.val().toLowerCase() || e1.val() === ""){
            document.querySelector("input#remail").setCustomValidity("Emails Do not match");
        }else if(e1.val().toLowerCase() === e2.val().toLowerCase()){
            document.querySelector("input#remail").setCustomValidity("");
        }
    })

    $(document).on('change keyup', '#remail', function () {
        let e1 = $("#email");
        let e2 = $("#remail");
        if(e1.val().toLowerCase() !== e2.val().toLowerCase() || e1.val() === ""){
            document.querySelector("input#remail").setCustomValidity("Emails Do not match");
        }else if(e1.val().toLowerCase() === e2.val().toLowerCase()){
            document.querySelector("input#remail").setCustomValidity("");
        }
    })

    $(document).on('click', '#verifybtn', function () {
        let body = `Hello<br>Enter to this link in order to verify your account:<br>http://localhost/PRJ_207416850_315989830/verify.php?email=`+email;
        let subject = `Petek - Account Activation`;
        $.ajax({
            url:"./sendEmail.php",
            type:"POST",
            data:({Email:email,Body:body, Subject:subject}),
            success:function(response){
                $(".verificationalert").html("an email has been Sent!");
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });
    });

    $(document).on('click', '#forgotPassword', function () {
        event.preventDefault();
        email = $('#lemail').val();
        let reset = Math.floor((Math.random() * 99999) + 1);
        let body = `Hello ${email}<br>Click on this link in order to change your current password:<br>http://localhost/PRJ_207416850_315989830/resetpassword.php?Email=`+email+`&Reset=`+reset;
        let subject = `Petek - Password Reset`;
        $.ajax({
            url:"./sendEmail.php",
            type:"POST",
            data:({Email:email,Body:body, Subject:subject}),
            success:function(response){
                $.ajax({
                    url:"./api/updatereset.php",
                    type:"POST",
                    data:({Email:email, Reset:reset}),
                    success:function(response){
                        let alert = `<div class="alert alert-success text-center" role="alert">
                                    you will get an email within a minute if you do have an account in Petek!
                                </div>`;
                        $(".alertc").html(alert);
                    },
                    error:function(xhr,status,error)  {
                        console.log(error);
                    }
                });
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });
    });

});