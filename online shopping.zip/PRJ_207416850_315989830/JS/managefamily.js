let FamilyDetails = new Vue({
    el: '#creationDate',
    data: {
        createDate: ""
    }
})


$(document).ready(function (){
    $(document).on('click', '#requestsbtn', function(){
        event.preventDefault();
        $('.modal.requests').fadeIn(function(){
            $('.modal.requests').modal('show');
        });
    });

    $(document).on('click', '#deletecomplete', function(){
        event.preventDefault();
        $('.modal.deletefamily').fadeOut(function(){
            $('.modal.deletefamily').modal('hide');
        });
        let familyID = $('.family:selected').data('id');

        $.ajax({
            url:"./api/deletefamily.php",
            type:"POST",
            data:({Family:familyID}),
            success:function(response){
                getFamilies();
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });
    });

    $(document).on('click', '#deletefamily', function(){
        event.preventDefault();
        let familyName = $('.family:selected').val()

        $('.dfamilyalert').html("You are about to delete <b>" + familyName + "</b> family.<br> Are you sure you want to delete it ?");                
        $('.modal.deletefamily').fadeIn(function(){
            $('.modal.deletefamily').modal('show');
        });
    });

    $(document).on('click', '.rmember', function(){
        event.preventDefault();
        let email = $(this).parents('td').siblings('.emailfield').html();
        let familyID = $('.family:selected').data('id');

        $(this).parents('tr').fadeOut(function(){
            $(this).parents('tr').remove();
        });

        $.ajax({
            url:"./api/removeMember.php",
            type:"POST",
            data:({Email:email,FamilyID:familyID}),
            success:function(response){
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });
    });

    $(document).on('click', '.rejectr', function(){
        event.preventDefault();
        let email = $(this).parents('td').siblings('.remailfield').html();
        $(this).parents('tr').fadeOut(function(){
            $(this).parents('tr').remove();
        });

        let familyID = $('.family:selected').data('id');
        $.ajax({
            url:"./api/removerequest.php",
            type:"POST",
            data:({Email:email,Family:familyID}),
            success:function(response){
                let requestCount = parseInt($('#requestCount').html())
                requestCount -= 1;
                $('#requestCount').html(requestCount);
                if(requestCount <= 0){
                    $('.modal.requests').fadeOut(function(){
                        $('.modal.requests').modal('hide');
                     });
                 }
             },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });
    });

    $(document).on('click', '.approver', function(){
        event.preventDefault();
        let email = $(this).parents('td').siblings('.remailfield').html();
        $(this).parents('tr').fadeOut(function(){
            $(this).parents('tr').remove();
        });
        

        addMemberToTable(email, "NOW", false);

        let familyID = $('.family:selected').data('id');

        $.ajax({
            url:"./api/removerequest.php",
            type:"POST",
            data:({Email:email,Family:familyID}),
            success:function(response){
                
                $.ajax({
                    url:"./api/addMemberToFamily.php",
                    type:"POST",
                    data:({Email:email, FamilyID:familyID}),
                    success:function(response){
                         let requestCount = parseInt($('#requestCount').html())
                         requestCount -= 1;
                        $('#requestCount').html(requestCount);
                        if(requestCount <= 0){
                            $('.modal.requests').fadeOut(function(){
                            $('.modal.requests').modal('hide');
                                });
                        }
                    },
                    error:function(xhr,status,error)  {
                        console.log(error);
                    }
                });
            },
            error:function(xhr,status,error)  {
                console.log(error);
            }
        });
    });

    $(document).on('click', '#familiess', function(){
        let familyID = $(this).children('.family:selected').data('id');

        showFamily(familyID);
        loadMembers(familyID);
        loadRequests(familyID);
    });

    function loadMembers(familyID){
        $.ajax({
            url: "./api/getfamilymembers.php?family="+familyID,
            type:"GET",
            success: function(data) {
                memberCount = data.length;
                emptyTable(1,0);
                let i = 0;
                let tr = ``;
                for(i; i < memberCount ; i++){
                    addMemberToTable(data[i]['MemberEmail'], data[i]['JoinDate'], parseInt(data[i]['isManager']))
                }
            }
        });
    }

    function loadRequests(familyID){
        $.ajax({
            url: "./api/getfamilyrequests.php?family="+familyID,
            type:"GET",
            success: function(data) {
                requestCount = data.length;
                $('#requestCount').html(requestCount)
                emptyTable(0,1);
                let i = 0;
                for(i; i < requestCount ; i++){
                    tr = `<tr>
                            <td class="text-break remailfield">${data[i]['ApplicantEmail']}</td>
                            <td><a href="" class="approver">Approve</a> | <a href="" class="rejectr">Reject</a></td>
                        </tr>`;
                    $('.table.requests').children('tbody').append(tr);
                }
            }
        });
    }
    
    function addMemberToTable(email, joindate, isManager){
        if(isManager){
            tr = `<tr>
                    <td class="emailfield">${email}</td>
                    <td>${joindate}</td>
                    <td></td>
                </tr>`;
        }else{
            tr = `<tr>
                    <td class="emailfield">${email}</td>
                    <td>${joindate}</td>
                    <td><a href="" class="rmember">Remove Member</a></td>
                </tr>`;
        }
        $('.table.members').children('tbody').prepend(tr);
    }

    function emptyTable(Member, Requests){
        if(Member)
            $('.table.members').children('tbody').html('');
        if(Requests)
            $('.table.requests').children('tbody').html('');
    }

    function isManager(){
        $.ajax({
            url: "./api/isManager.php",
            type:"GET",
            success: function(data) {
                if(data[0]['FamilyID'] == null){
                    window.location.href = "index.php";
                }
            }
        });
    }

    function getFamilies(){
        $('#familiess').html("");
        
        $.ajax({
            url: "./api/getfamilybymanager.php",
            type:"GET",
            success: function(data) {
                if(data.length == 0)
                    window.location.href = "familylists.php";
                let i = 0;

                for(i; i< data.length; i++){
                    $('#familiess').append(`<option class="family" data-id=${data[i]['FamilyID']}> ${data[i]['FamilyName']} </option>`);
                }
                showFamily(data[0]['FamilyID'])
            }
        });
    }

    function showFamily(familyID){
        $.ajax({
            url: "./api/getfamilybymanager.php?family="+familyID,
            type:"GET",
            success: function(data) {
                if(data.length == 0)
                    window.location.href = "familylists.php";
                FamilyDetails.createDate = data[0]['CreationDate'];
            }
        });
        loadMembers(familyID);
        loadRequests(familyID);

    }

    getFamilies();
    isManager();

});