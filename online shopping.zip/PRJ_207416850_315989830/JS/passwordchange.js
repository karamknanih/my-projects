$(document).ready(function (){
    $(document).on('click', '#changePW', function(){
        event.preventDefault();
        currentPass = $('#currentPassword').val();
        newPass = $('#newPassword').val();
        repeatPass = $('#repeatPassword').val();
        if(newPass.length < 5 || repeatPass.length < 5){
            alert = `<div class="alert alert-danger" role="alert">
                        New password MUST have atleast 5 characters.
                    </div>`;
            $('.alerts').html("");        
            $('.alerts').append(alert);
            $('#repeatPassword').val('');
            $('#newPassword').val('').focus();
            return;
        }
        else if(newPass != repeatPass){
            alert = `<div class="alert alert-danger" role="alert">
                        New Password does not match the repeated.
                    </div>`;
            $('.alerts').html("");        
            $('.alerts').append(alert);
            $('#repeatPassword').val('').focus();
            return;
        }

        $.ajax({
            url: "./api/userexists.php?Password=" + currentPass,
            type:"GET",
            success: function(data) {
                if(data.length == 0){
                    alert = `<div class="alert alert-danger" role="alert">
                                Current Password is Incorrect
                            </div>`;
                    $('.alerts').html("");        
                    $('.alerts').append(alert);
                    $('#currentPassword').val('').focus();
                }else{
                    $.ajax({
                        url:"./api/setNewPassword.php",
                        type:"POST",
                        data:({Email:data[0]['Email'], OldPass:currentPass, NewPass:newPass }),
                        success:function(response){
                            alert = `<div class="alert alert-success" role="alert">
                                        Password has been successfully changed.
                                    </div>`;
                            $('.alerts').html("");        
                            $('.alerts').append(alert);
                            $('#currentPassword').val('');
                            $('#repeatPassword').val('');
                            $('#newPassword').val('');
                        },
                        error:function(xhr,status,error)  {
                            console.log(error);
                        }
                    });
                }
            }
        });
    });

    $(document).on('click', '#resetPW', function(){
        newPass = $('#newPassword').val();
        repeatPass = $('#repeatPassword').val();
        if(newPass.length < 5 || repeatPass.length < 5){
            event.preventDefault();
            alert = `<div class="alert alert-danger" role="alert">
                        New password MUST have atleast 5 characters.
                    </div>`;
            $('.alerts').html("");        
            $('.alerts').append(alert);
            $('#repeatPassword').val('');
            $('#newPassword').val('').focus();
            return;
        }
        else if(newPass != repeatPass){
            event.preventDefault();
            alert = `<div class="alert alert-danger" role="alert">
                        New Password does not match the repeated.
                    </div>`;
            $('.alerts').html("");        
            $('.alerts').append(alert);
            $('#repeatPassword').val('').focus();
            return;
        }
    });
});