let productToRemove = -1;
let productToEdit = -1;

$(document).ready(function (){

    $(document).on('click', '.btnRemove', function(){
        event.preventDefault();
        $('.modal.remove').fadeIn(function(){
            $('.modal.remove').modal('show');
        });
        productToRemove = $(this).parents('tr').data('id');
        $('.mrbody').html("You are about to delete <b>" + $(this).parents('td').siblings('.name').html() + "</b> from your list");
        
    });

    $(document).on('click', '#pdelete', function(){
        event.preventDefault();
        $('.modal.remove').fadeOut(function(){
            $('.modal.remove').modal('hide');
        });
        $('tbody tr').each(function(){
            if($(this).data('id') == productToRemove){
                $(this).fadeOut(function(){
                    $(this).remove();
                    $.ajax({
                        url:"./api/removeuserproduct.php",
                        type:"POST",
                        data:({ProductID:productToRemove}),
                        success:function(response){
                            productToRemove = -1;
                        },
                        error:function(xhr,status,error)  {
                            console.log(error);
                        }
                    });
                });
            }
        })
    });

    $(document).on('click', '.btnEdit', function(){
        event.preventDefault();
        $('.modal.edit').fadeIn(function(){
            $('.modal.edit').modal('show');
        });
        productToEdit = $(this).parents('tr').data('id');
        $('.mebody').html("You are about to edit product: <b>" + $(this).parents('td').siblings('.name').html() + "</b>")
    });

    $(document).on('click', '#editbtn', function(){
        event.preventDefault();
        $('.modal.edit').fadeOut(function(){
            $('.modal.edit').modal('hide');
        });
        $('tbody tr').each(function(){
            if($(this).data('id') == productToEdit){
                $(this).children('.name').html($('#productname').val());
                let productName = $('#productname').val();
                $('#productname').val('');
                $.ajax({
                    url:"./api/editproductName.php",
                    type:"POST",
                    data:({ProductID:productToEdit, ProductName:productName}),
                    success:function(response){
                        productToEdit = -1;
                    },
                    error:function(xhr,status,error)  {
                        console.log(error);
                    }
                });
            }
        })
    });

    function loadproducts(){
        $.ajax({
            url: "./api/getboughtproducts.php",
            type:"GET",
            success: function(data) {
                productCount = data.length;
                $('.products').children('tbody').html('');
                let tr = ``;
                let i = 0;
                for(i; i < productCount ; i++){
                    let quantity = parseInt(data[i]['Quantity']) == 0 ? "" : parseInt(data[i]['Quantity']); 
                    tr = `<tr data-id=${data[i]['ID']}>
                            <td class="name" id="fname">${data[i]['Name']}</td>
                            <td class="listnum">${data[i]['ListID']}</td>
                             <td class="quantity" id="quantity">${quantity}</td>
                            <td>
                                <button type="submit" class="btnEdit btn btn-outline-warning">Edit</button>
                                <button type="submit" class="btnRemove btn btn-outline-danger">Remove</button>
                            </td>
                        </tr>`;
                    $('.products').children('tbody').append(tr);
                }
            }
        });
    }

    loadproducts();

});