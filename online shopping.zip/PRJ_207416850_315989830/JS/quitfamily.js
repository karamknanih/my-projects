$(document).ready(function (){

    function loadFamily(){
        $.ajax({
            url: "./api/getuserfamily.php",
            type:"GET",
            success: function(data) {
                if(data.length == 0)
                    window.location.href = "index.php";
                let alert = `You are about to quit your family - <b>${data[0]['FamilyName']}</b>`;
                $('.fheading').html(alert);
            }
        });
    }

    function isManager(){
        $.ajax({
            url: "./api/isManager.php",
            type:"GET",
            success: function(data) {
                if(data[0]['FamilyID'] != null){
                    window.location.href = "managefamily.php";
                }
            }
        });
    }

    $(document).on('click', '#quitfamily', function(){
        event.preventDefault();
        $.ajax({
            url: "./api/getuserfamily.php",
            type:"GET",
            success: function(data) {
                if(data.length == 0){
                    window.location.href = "allfamilies.php";
                }

                $.ajax({
                    url:"./api/removeMember.php",
                    type:"POST",
                    data:({Email:data[0]['Email']}),
                    success:function(response){
                        window.location.href = "index.php?family=" + data[0]['FamilyName'] + "&quit=true";
                    },
                    error:function(xhr,status,error)  {
                        console.log(error);
                    }
                });

            }
        });
    });

    isManager();
    loadFamily();
});