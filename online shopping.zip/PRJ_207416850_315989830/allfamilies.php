<?php 
  require_once('db.php');
  
  session_start();
  $email = null;
  // Check if there any Cookie to validate login
  if(isset($_COOKIE['LogCheck'])){
    if(!is_null($_COOKIE['LogCheck'])){
      $cookie = htmlspecialchars($_COOKIE['LogCheck']);
      $sql = "SELECT `Email` FROM `users` WHERE `Cookie`='$cookie'";
      $result = $conn->query($sql);
      if($result == true && $cookie > 0){
          $row = $result->fetch_assoc();
          if(!is_null($row)){
            $email = $row['Email'];
          }
          else{
            session_start();
            $_SESSION = array();
            session_destroy();
            unset($_COOKIE['LogCheck']);
            setcookie('LogCheck',null, time()-(60*60*24));
            header("Location:login.php?status=showMsg");
          }
      }
    }
  }

  // Check if there any SESSION to validate login
  if(isset($_SESSION['email']) && is_null($email)){
    $email = $_SESSION['email'];
    $sql = "SELECT `Email` FROM `users` WHERE `Email`='$email'";
    $result = $conn->query($sql);
    if($result == true ){
      $row = $result->fetch_assoc();
      if(is_null($row['Email'])){
        $_SESSION = array();
        session_destroy();
        header("Location:login.php?status=showMsg");
      }
    }
  }
  // redirect to login page if there isn't any SESSION or Cookie
  else if(is_null($email)){
    header("Location:login.php?status=showMsg");
  }
  if(is_null($email)){
    header("Location:login.php?status=showMsg");
  }

  $_SESSION['email'] = $email;
  require_once('parts/header.php');

?>
<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Petek - Family</title>
        <link rel="stylesheet" type="text/css"href="css/styles.css">
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <!-- <link rel="stylesheet" type="text/css"href="css/all.css"> -->
        <link rel="stylesheet" type="text/css"href="css/family.css">
        <link rel="icon" href="logo.png" type="image" sizes="16x16">
    </head>
    <body >
        <div class="modal createfamily" tabindex="-1" role="dialog">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Create Family</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="x">&times;</span>
                  </button>
                </div>
                <form>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="familyName">Family Name</label>
                            <input type="text" class="form-control" id="familyName" placeholder="Family Name">
                        </div>
                        <div class="form-group">
                            <label for="familyDescription">Family Description</label>
                            <textarea class="form-control" id="familyDescription" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" id="createbtn">Create</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
                </form>
            </div>
          </div>


        <div class="container">
            <h1 class="text-center" id="title">Families</h1>
            <hr>
                <div class="row justify-content-center">
                    <button type="button" href="#" class="btn btn-primary" id="creatfamily">Create Family</button>
                </div>
            <hr>
            <div class="allFamilies">
                
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
        <script src="./JS/families.js"> </script>
        <script src="./JS/head.js"> </script>

    </body>
    <?php require_once "parts/footer.php"; ?>
 
</html>