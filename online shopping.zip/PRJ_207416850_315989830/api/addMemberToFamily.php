<?php require("../db.php");?>
<?php 
header('Content-Type: application/json');
session_start();
$familyID = $_POST['FamilyID'];
$email = null;
if(isset($_POST['Email'])){
    if(!is_null($_POST['Email'])){
        $email = $_POST['Email'];
    }
}
if(is_null($email))
    $email = $_SESSION['email'];

$sql = "INSERT INTO `familymembers` ( `MemberEmail`, `FamilyID` )  VALUES ('$email', '$familyID')";


if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();