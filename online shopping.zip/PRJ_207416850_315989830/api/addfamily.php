<?php require("../db.php");?>
<?php 
header('Content-Type: application/json');
session_start();
$email = $_SESSION['email'];
$description = $_POST['Description'];
$familyName = $_POST['FamilyName'];

$sql = "INSERT INTO `family`( `FamilyName`, `Description` , `ManagerEmail`) VALUES ('$familyName','$description','$email')";

if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();