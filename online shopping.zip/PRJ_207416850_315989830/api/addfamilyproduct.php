<?php require("../db.php");

header('Content-Type: application/json');
session_start();
$email = $_SESSION['email'];

$name = htmlspecialchars($_POST['name']);
$family = htmlspecialchars($_POST['Family']);

if(isset($_POST['quantity'])){
    $quantity = htmlspecialchars($_POST['quantity']);

    $sql = "INSERT INTO `allproducts` (`Name`, `Quantity`) VALUES ('$name', '$quantity')";
    if(isset($_POST['purchased']))
    {
        $ispurchased = htmlspecialchars($_POST['purchased']);
        $sql = "INSERT INTO `allproducts` (`Name`, `Quantity`, `IsPurchased`) VALUES ('$name', '$quantity','$ispurchased')";
    }
}else{
    $sql = "INSERT INTO `allproducts` (`Name`) VALUES ('$name')";
    if(isset($_POST['purchased']))
    {
        $sql = "INSERT INTO `allproducts` (`Name`,`IsPurchased`) VALUES ('$name', '$quantity', '$ispurchased')";
    }
}


if ($conn->query($sql)===TRUE) {
    $sql = "INSERT INTO `familyproducts` (`FamilyID`,`ProductID`) VALUES ('$family','$conn->insert_id');";
    if ($conn->query($sql)===TRUE) {
        echo json_encode($conn->insert_id);
    }
    else {
        echo json_encode($conn->error);
    }}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();