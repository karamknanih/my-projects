<?php require("../db.php");?>
<?php 
header('Content-Type: application/json');
session_start();
$email = $_SESSION['email'];
$list = $_POST['list'];

$sql = "INSERT INTO `userlists`( `UserEmail`, `ListID`)
 VALUES ('$email','$list')";

if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();