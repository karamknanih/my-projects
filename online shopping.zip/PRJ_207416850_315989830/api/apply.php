<?php require("../db.php");

header('Content-Type: application/json');
session_start();
$email = $_SESSION['email'];

$familyID = htmlspecialchars($_POST['FamilyID']);

$sql = "INSERT INTO `applications` (`ApplicantEmail`, `FamilyID`) VALUES ('$email', '$familyID')";

if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();