<?php require("../db.php");

header('Content-Type: application/json');
session_start();
$email = $_SESSION['email'];
$family = $_POST['Family'];

$sql = "DELETE FROM `family` WHERE `ManagerEmail` = '$email' AND `FamilyID` = $family";

if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();