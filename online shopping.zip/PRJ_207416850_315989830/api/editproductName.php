<?php require("../db.php");

header('Content-Type: application/json');
session_start();
$email = $_SESSION['email'];

$productid = htmlspecialchars($_POST['ProductID']);
$productName = htmlspecialchars($_POST['ProductName']);

$sql = "UPDATE `allproducts` SET `allproducts`.`Name` = '$productName' WHERE `allproducts`.`ID` IN (SELECT `ProductID` FROM `productlist` WHERE `UserEmail` = '$email' AND `ProductID` = $productid)";

if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();