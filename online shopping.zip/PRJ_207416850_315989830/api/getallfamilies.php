<?php require("../db.php");

header('Content-Type: application/json');

session_start();
$email = $_SESSION['email'];
$sql = "SELECT `f`.`FamilyID`, `f`.`FamilyName` , `f`.`Description`, CASE WHEN `a`.`ApplicantEmail` is null THEN 0 else 1 END as `Applied`, CASE WHEN `fm`.`FamilyID` is null THEN 0 else 1 END as `isMember` 
FROM (`family` `f` left outer join `applications` `a` ON `f`.`FamilyID` = `a`.`FamilyID` AND `a`.`ApplicantEmail` = '$email') left outer join `familymembers` `fm` ON `fm`.`FamilyID` = `f`.`FamilyID` AND `fm`.`MemberEmail` = '$email'";

$result = $conn->query($sql);
$lists = array();
while($row = $result->fetch_assoc()){
    $lists[] = $row;
}
echo json_encode($lists);
$conn->close();
