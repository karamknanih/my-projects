<?php require("../db.php");

header('Content-Type: application/json');

session_start();
$email = $_SESSION['email'];
$sql = "SELECT `p`.`ListID`, `a`.`ID`,`a`.`Name`, `a`.`Quantity` FROM `productlist` `p` inner join `allproducts` `a` ON `p`.`ProductID` = `a`.`ID` AND `a`.`IsPurchased` = 1 WHERE `p`.`UserEmail` = '$email' ORDER BY `p`.`ListID`, `a`.`Name`";

$result = $conn->query($sql);
$lists = array();
while($row = $result->fetch_assoc()){
    $lists[] = $row;
}
echo json_encode($lists);
$conn->close();
