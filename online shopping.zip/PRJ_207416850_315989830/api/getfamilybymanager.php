<?php require("../db.php");

header('Content-Type: application/json');

session_start();
$email = $_SESSION['email'];

$family = null;
$sql = "";

if(isset($_GET['family'])){
    if(!is_null($_GET['family'])){
        $family = $_GET['family'];
    }
}
if(is_null($family)){
    $sql = "SELECT `f`.`FamilyName`, `f`.`FamilyID`, DATE_FORMAT(`f`.`CreationDate`, '%M %d %Y') as `CreationDate`
        FROM `family` `f` 
        WHERE `f`.`ManagerEmail` =  '$email'";
}else{
    $sql = "SELECT `f`.`FamilyName`, `f`.`FamilyID`, DATE_FORMAT(`f`.`CreationDate`, '%M %d %Y') as `CreationDate`
        FROM `family` `f` 
        WHERE `f`.`ManagerEmail` =  '$email' AND `f`.`FamilyID` = '$family'";
}


$result = $conn->query($sql);
$lists = array();
while($row = $result->fetch_assoc()){
    $lists[] = $row;
}
echo json_encode($lists);
$conn->close();
