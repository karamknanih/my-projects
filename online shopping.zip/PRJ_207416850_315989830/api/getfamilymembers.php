<?php require("../db.php");

header('Content-Type: application/json');

session_start();
$email = $_SESSION['email'];
$family = "";

if(isset($_POST['family'])){
    if(!is_null($_POST['family'])){
        $family = $_POST['family'];
    }
}
if(isset($_GET['family'])){
    if(!is_null($_GET['family'])){
        $family = $_GET['family'];
    }
}

$sql = "SELECT `fm`.`MemberEmail`, DATE_FORMAT(`fm`.`JoinDate`, '%M %d %Y') as `JoinDate`,
        CASE 
            WHEN `fm`.`MemberEmail` = `f`.`ManagerEmail` THEN 1
            ELSE 0
        END as `isManager`
        FROM `familymembers` `fm` inner join `family` `f` ON `fm`.`FamilyID` = `f`.`FamilyID` AND `f`.`ManagerEmail` =  '$email' AND `f`.`FamilyID` = '$family'
        ORDER BY `fm`.`JoinDate`";

$result = $conn->query($sql);
$lists = array();
while($row = $result->fetch_assoc()){
    $lists[] = $row;
}
echo json_encode($lists);
$conn->close();
