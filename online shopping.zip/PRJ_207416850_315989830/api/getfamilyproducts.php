<?php require("../db.php");

header('Content-Type: application/json');

session_start();
$email = $_SESSION['email'];
$family = null;
if(isset($_GET['family'])){
    if(!is_null($_GET['family'])){
        $family = $_GET['family'];
    }
}
$sql = '';
if(is_null($family)){
    $sql = "SELECT `p`.`ID`, `p`.`Name` ,`p`.`Quantity` ,`p`.`IsPurchased`, DATE_FORMAT(`fm`.`JoinDate`, '%M %d %Y') as `JoinDate`
    FROM (`familyproducts` `fp` inner join `allproducts` `p` ON `fp`.`ProductID` = `p`.`ID`) inner join `familymembers` `fm` ON `fp`.`FamilyID` = `fm`.`FamilyID` AND `fm`.`MemberEmail` =  '$email'
    ORDER BY `p`.`IsPurchased`, `p`.`Name`";
}else{
    $sql = "SELECT `p`.`ID`, `p`.`Name` ,`p`.`Quantity` ,`p`.`IsPurchased`, DATE_FORMAT(`fm`.`JoinDate`, '%M %d %Y') as `JoinDate`
        FROM (`familyproducts` `fp` inner join `allproducts` `p` ON `fp`.`ProductID` = `p`.`ID`) inner join `familymembers` `fm` ON `fp`.`FamilyID` = `fm`.`FamilyID` AND `fm`.`MemberEmail` =  '$email'
        WHERE `fp`.`FamilyID` =  '$family'
        ORDER BY `p`.`IsPurchased`, `p`.`Name`";
}

$result = $conn->query($sql);
$lists = array();
while($row = $result->fetch_assoc()){
    $lists[] = $row;
}
echo json_encode($lists);
$conn->close();
