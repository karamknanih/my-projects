<?php require("../db.php");

header('Content-Type: application/json');

session_start();
$email = $_SESSION['email'];
$family = $_GET['family'];

$sql = "SELECT `a`.`ApplicantEmail`
        FROM `applications` `a` inner join `family` `f` ON `a`.`FamilyID` = `f`.`FamilyID` AND `f`.`FamilyID` = $family AND `f`.`ManagerEmail` =  '$email'";

$result = $conn->query($sql);
$lists = array();
while($row = $result->fetch_assoc()){
    $lists[] = $row;
}
echo json_encode($lists);
$conn->close();
