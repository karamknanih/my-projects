<?php require("../db.php");

header('Content-Type: application/json');

session_start();
$email = $_SESSION['email'];
$listid = null;
if(isset($_GET['List'])){
    if(!is_null($_GET['List'])){
        $listid = htmlspecialchars($_GET['List']);
    }
}
$sql = "SELECT `allp`.* FROM `productlist` `pl` inner join `allproducts` `allp` ON `pl`.`ProductID` = `allp`.`ID` WHERE `pl`.`UserEmail` = '$email' AND `pl`.`ListID` = $listid ORDER BY `allp`.`IsPurchased`, `allp`.`Name`";

if(isset($_GET['product'])){
    if(!is_null($_GET['product'])){
        $product = htmlspecialchars($_GET['product']);
        $sql = "SELECT * FROM `productlist`, `allproducts` WHERE `productlist`.`UserEmail` = '$email' AND `productlist`.`ListID` = '$product' AND `allproducts`.`ID` = `productlist`.`ProductID` ORDER BY `allproducts`.`IsPurchased`, `allproducts`.`Name`";
    }
}
if(isset($_GET['autocomplete'])){
    if(!is_null($_GET['autocomplete'])){
        $sql = "SELECT `allproducts`.`Name` FROM `productlist`, `allproducts` WHERE `productlist`.`UserEmail` = '$email' AND `allproducts`.`ID` = `productlist`.`ProductID` ORDER BY `allproducts`.`Name`";
    }
}
$result = $conn->query($sql);
$lists = array();
while($row = $result->fetch_assoc()){
    $lists[] = $row;
}
echo json_encode($lists);
$conn->close();
