<?php require("../db.php");

header('Content-Type: application/json');

session_start();
$email = $_SESSION['email'];
$sql = "SELECT `fm`.`FamilyID`, DATE_FORMAT(`fm`.`JoinDate`, '%M %d %Y') as `JoinDate` , `f`.`FamilyName`, `fm`.`MemberEmail` as `Email` FROM `familymembers` `fm` inner join `family` `f` ON `fm`.`FamilyID` = `f`.`FamilyID` WHERE `fm`.`MemberEmail` = '$email'";

$result = $conn->query($sql);
$lists = array();
while($row = $result->fetch_assoc()){
    $lists[] = $row;
}
echo json_encode($lists);
$conn->close();
