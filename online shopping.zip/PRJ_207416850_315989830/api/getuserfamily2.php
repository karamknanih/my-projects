<?php require("../db.php");

header('Content-Type: application/json');

session_start();
$email = $_SESSION['email'];
$sql = "SELECT `FamilyID` FROM `family` WHERE `ManagerEmail` = '$email'";

$result = $conn->query($sql);
$lists = array();
while($row = $result->fetch_assoc()){
    $lists[] = $row;
}
echo json_encode($lists);
$conn->close();
