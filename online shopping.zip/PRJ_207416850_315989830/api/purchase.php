<?php require("../db.php");

header('Content-Type: application/json');
session_start();
$email = $_SESSION['email'];

$list = htmlspecialchars($_POST['TableID']);
$productid = htmlspecialchars($_POST['ProductID']);
$purchase = htmlspecialchars($_POST['Purchase']);

$sql = "UPDATE `productlist`,`allproducts` SET `allproducts`.`IsPurchased`= $purchase WHERE `productlist`.`UserEmail` = '$email' AND `productlist`.`ListID` = '$list' AND `productlist`.`ProductID` = '$productid' AND `allproducts`.`ID` = `productlist`.`ProductID`";

if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();