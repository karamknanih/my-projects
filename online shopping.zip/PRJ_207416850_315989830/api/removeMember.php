<?php require("../db.php");?>
<?php 
header('Content-Type: application/json');
session_start();
$email = null;
if(isset($_POST['Email'])){
    if(!is_null($_POST['Email'])){
        $email = $_POST['Email'];
    }
}
if(is_null($email))
    $email = $_SESSION['email'];

$familyID = $_POST['FamilyID'];

$sql = "DELETE FROM `familymembers` WHERE `MemberEmail` = '$email' AND `FamilyID` = '$familyID'";

if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();