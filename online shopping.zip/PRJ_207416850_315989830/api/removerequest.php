<?php require("../db.php");?>
<?php 
header('Content-Type: application/json');
session_start();

$email = $_POST['Email'];
$family = $_POST['Family'];

$sql = "DELETE FROM `applications` WHERE `ApplicantEmail` = '$email' AND `FamilyID` = $family";


if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();