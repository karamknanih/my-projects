<?php require("../db.php");?>
<?php 
header('Content-Type: application/json');
session_start();
$email = $_POST['Email'];
$oldpass = $_POST['OldPass'];
$newpass = $_POST['NewPass'];

$sql = "UPDATE `users` SET `Pass` = $newpass WHERE `Email` = '$email' and `Pass` = $oldpass";

if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();