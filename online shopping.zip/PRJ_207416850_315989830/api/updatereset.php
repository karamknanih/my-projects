<?php require("../db.php");?>
<?php 
header('Content-Type: application/json');
session_start();
$email = $_POST['Email'];
$reset = $_POST['Reset'];

$sql = "UPDATE `users` SET `resetpw` = $reset WHERE `Email` = '$email'";

if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
}else {
    echo json_encode($conn->error);
}

// end of the file
$conn->close();