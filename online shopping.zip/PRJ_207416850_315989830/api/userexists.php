<?php require("../db.php");

header('Content-Type: application/json');

session_start();
$email = $_SESSION['email'];
$pass = $_GET['Password'];

$sql = "SELECT `Email`
        FROM `users` `u` 
        WHERE `Email` =  '$email' and `Pass` = $pass";

$result = $conn->query($sql);
$lists = array();
while($row = $result->fetch_assoc()){
    $lists[] = $row;
}
echo json_encode($lists);
$conn->close();
