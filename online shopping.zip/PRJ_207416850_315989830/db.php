<?php
$servername = "localhost";
$username = "root";
$password = "";
// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) 
    die("Connection failed: " . $conn->connect_error);
    
$dbName = "PRJ_207416850_315989830";
if (!mysqli_select_db($conn,$dbName)){
    $sql = "CREATE DATABASE $dbName";
    if ($conn->query($sql) === TRUE) {
        echo "Database created successfully";
    }else {
        echo "Error creating database: " . $conn->error;
    }
}

$conn = new mysqli($servername, $username, $password,$dbName);


$sql = "CREATE TABLE IF NOT EXISTS `users` (
    `Email` varchar(255) NOT NULL,
    `Pass` varchar(255) NOT NULL,
    `Username` varchar(255) DEFAULT NULL,
    `Phone` varchar(10) DEFAULT NULL,
    `cookie` int(10) NOT NULL,
    `resetpw` int(6) NOT NULL,
    `isVerified` int(1) DEFAULT 0,
    PRIMARY KEY (`Email`)
  );";
if ($conn->query($sql) === FALSE) {
    echo "Error creating table: " . $conn->error;
}

$sql = "CREATE TABLE IF NOT EXISTS `userlists` (
    `UserEmail` varchar(255) NOT NULL,
    `ListID` int(11) NOT NULL DEFAULT 1,
    PRIMARY KEY (`UserEmail`,`ListID`),
	CONSTRAINT FK_UserEmail1 FOREIGN KEY (`UserEmail`) REFERENCES `users`(`Email`) ON DELETE CASCADE ON UPDATE CASCADE
);";
if ($conn->query($sql) === FALSE) {
    echo "Error creating table: " . $conn->error;
}

$sql = "CREATE TABLE IF NOT EXISTS `allproducts` (
    `ID` int(11) NOT NULL AUTO_INCREMENT,
    `Name` varchar(255) NOT NULL,
    `Quantity` int(11) DEFAULT NULL,
    `IsPurchased` int(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (`ID`)
);";
if ($conn->query($sql) === FALSE) {
    echo "Error creating table: " . $conn->error;
}

$sql = "CREATE TABLE IF NOT EXISTS `productlist` (
    `ProductID` int(11) NOT NULL,
    `ListID` int(11) NOT NULL,
    `UserEmail` varchar(255) NOT NULL,
    PRIMARY KEY (`UserEmail`,`ListID`,`ProductID`),
	CONSTRAINT FK_UserProducts FOREIGN KEY (`UserEmail`,`ListID`) REFERENCES `userlists`(`UserEmail`,`ListID`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT FK_UserProducts2 FOREIGN KEY (`ProductID`) REFERENCES `allproducts`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE
);";

if ($conn->query($sql) === FALSE) {
    echo "Error creating table: " . $conn->error;
}

$sql = "CREATE TABLE IF NOT EXISTS `family` (
    `FamilyID` int(11) NOT NULL AUTO_INCREMENT,
    `FamilyName` varchar(255) NOT NULL,
    `Description` varchar(2000) NOT NULL,
    `CreationDate` datetime NOT NULL DEFAULT current_timestamp(),
    `ManagerEmail` varchar(255) NOT NULL,
    PRIMARY KEY (`FamilyID`),
    CONSTRAINT FK_ManagerFamily FOREIGN KEY (`ManagerEmail`) REFERENCES `users`(`Email`) ON DELETE CASCADE ON UPDATE CASCADE
);";

if ($conn->query($sql) === FALSE) {
    echo "Error creating table: " . $conn->error;
}

$sql = "ALTER TABLE `users`
ADD CONSTRAINT `FK_UserFamily` FOREIGN KEY (`Family`) REFERENCES `family` (`FamilyID`) ON DELETE SET NULL ON UPDATE SET NULL;";

$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS `applications` (
    `ApplicantEmail` varchar(255) NOT NULL,
    `FamilyID` int(11) NOT NULL,
    PRIMARY KEY (`ApplicantEmail`,`FamilyID`),
    CONSTRAINT FK_Apply FOREIGN KEY (`FamilyID`) REFERENCES `family`(`FamilyID`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT FK_EmailApply FOREIGN KEY (`ApplicantEmail`) REFERENCES `users`(`Email`) ON DELETE CASCADE ON UPDATE CASCADE
  );";

if ($conn->query($sql) === FALSE) {
    echo "Error creating table: " . $conn->error;
}

$sql = "CREATE TABLE IF NOT EXISTS `familyproducts` (
    `FamilyID` int(11) NOT NULL,
    `ProductID` int(11) NOT NULL,
    PRIMARY KEY (`ProductID`,`FamilyID`),
    CONSTRAINT FK_FamilyProduct FOREIGN KEY (`FamilyID`) REFERENCES `family`(`FamilyID`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT FK_FamilyProduct2 FOREIGN KEY (`ProductID`) REFERENCES `allproducts`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE
    );";

if ($conn->query($sql) === FALSE) {
    echo "Error creating table: " . $conn->error;
}

$sql = "CREATE TABLE IF NOT EXISTS `familymembers` (
    `MemberEmail` varchar(255) NOT NULL,
    `FamilyID` int(11) NOT NULL,
    `JoinDate` datetime NOT NULL DEFAULT current_timestamp(),
    PRIMARY KEY (`MemberEmail`,`FamilyID`),
    CONSTRAINT FK_Member FOREIGN KEY (`FamilyID`) REFERENCES `family`(`FamilyID`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT FK_Familyy FOREIGN KEY (`MemberEmail`) REFERENCES `users`(`Email`)
  );";

if ($conn->query($sql) === FALSE) {
    echo "Error creating table: " . $conn->error;
}


$sql = "CREATE TRIGGER `OnCreate` AFTER INSERT ON `family` FOR EACH ROW INSERT INTO `familymembers` ( `MemberEmail`, `FamilyID` )  VALUES (NEW.ManagerEmail, NEW.FamilyID);";

if ($conn->query($sql) === FALSE) {
    // echo "Error creating table: " . $conn->error;
}