<?php 
  require_once('db.php');
  session_start();
  $email = null;
  // Check if there any Cookie to validate login
  if(isset($_COOKIE['LogCheck'])){
    if(!is_null($_COOKIE['LogCheck'])){
      $cookie = htmlspecialchars($_COOKIE['LogCheck']);
      $sql = "SELECT `Email` FROM `users` WHERE `Cookie`='$cookie'";
      $result = $conn->query($sql);
      if($result == true && $cookie > 0){
          $row = $result->fetch_assoc();
          if(!is_null($row)){
            $email = $row['Email'];
          }
          else{
            session_start();
            $_SESSION = array();
            session_destroy();
            unset($_COOKIE['LogCheck']);
            setcookie('LogCheck',null, time()-(60*60*24));
            header("Location:login.php?status=showMsg");
          }
      }
    }
  }

  // Check if there any SESSION to validate login
  if(isset($_SESSION['email']) && is_null($email)){
    $email = $_SESSION['email'];
    $sql = "SELECT `Email` FROM `users` WHERE `Email`='$email'";
    $result = $conn->query($sql);
    if($result == true ){
      $row = $result->fetch_assoc();
      if(is_null($row['Email'])){
        $_SESSION = array();
        session_destroy();
        header("Location:login.php?status=showMsg");
      }
    }
  }
  // redirect to login page if there isn't any SESSION or Cookie
  else if(is_null($email)){
    header("Location:login.php?status=showMsg");
  }
  if(is_null($email)){
    header("Location:login.php?status=showMsg");
  }

  $_SESSION['email'] = $email;

  require_once "parts/header.php"; 
?>

<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Petek - Family</title>
        <link rel="stylesheet" type="text/css"href="css/styles.css">
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <!-- <link rel="stylesheet" type="text/css"href="css/all.css"> -->
        <link rel="stylesheet" type="text/css"href="css/family.css">
        <link rel="icon" href="logo.png" type="image" sizes="16x16">
    </head>

    <body >
        <div class="modal addproduct" tabindex="-1" role="dialog" id="exampleModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title">Add Product</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="x">&times;</span>
                    </button>
                    </div>
                    <form id="addProduct" class="form-group">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-6">
                                    <label for="name"><b>Product Name</b></label>
                                </div>
                                <div class="col-6">
                                    <input type="text" id="name" placeholder="Product Name" name="pname" class="form-control name" autocomplete="off" minlength="1" required>
                                </div>
                                <br><br>
                                <div class="col-6">
                                    <label for="quantity"><b>Quantity </b><span class="opt">(Optional)</span></label>
                                </div>
                                <div class="col-6">
                                    <input type="number" id="quantity" placeholder="Quantity" name="quantity" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success" id="submitadding" >Submit</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Done</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="modal remove" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Product Deletion</h5>
                </div>
                <div class="modal-body">
                  <p class="mbody">You are about to delete - - from your list</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" id="pdelete">Delete</button>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
              </div>
            </div>
        </div>

        <div class="modal quitfamily" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Quit Family </h5>
                </div>
                <div class="modal-body">
                  <p id="familydeletionbody">You are about to quit family:<b> {{ familyDeletion }} </b></p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" id="pQuit">Quit</button>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
              </div>
            </div>
        </div>

        <div class="container ">
            <h2 class="text-center">Family Lists</h2>
            <div id="familyDetails">
            <hr>
              <!-- <h5 class="text-center fname">{{name}}</h5> -->
              <div class="row justify-content-center">
                <div class="col-md-4">
                  <select class="form-control" id="familiess"></select>
                </div>
              </div>
              <div class="text-center">
                <small class="joinDate"><b>Join Date:</b> {{ joinDate }}</small>
              </div>
            </div>
            <hr>
                <div class="row justify-content-end">
                    <div class="col-md-5 col-7">
                      <button type="button" class="btn btn-outline-dark" id="addproduct">Add Product</button>
                    </div>
                    <div class="col-md-2 col-5 quitfam">
                    </div>
                </div>
            <hr>
            <div class=" container table-responsive">
              <table class="table table-light table-hover table-striped shadow-lg familyproducts">
                <thead>
                    <tr>
                      <th scope="col">Product Name</th>
                      <th scope="col">Quantity</th>
                      <th scope="col">Purchased</th>
                      <th ></th>
                    </tr>
                  </thead>
                <tbody>
                  
                </tbody>
              </table>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
        <script src="./JS/familylists.js"> </script>
        <script src="http://code.jquery.com/ui/1.12.0/jquery-ui.js" ></script>
        <script src="./JS/head.js"> </script>
    </body>
    
    <?php require_once "parts/footer.php"; ?>
</html>