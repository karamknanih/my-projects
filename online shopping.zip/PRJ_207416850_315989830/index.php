<?php 
  require_once('db.php');
  session_start();
  $email = null;
  // Check if there any Cookie to validate login
  if(isset($_COOKIE['LogCheck'])){
    if(!is_null($_COOKIE['LogCheck'])){
      $cookie = htmlspecialchars($_COOKIE['LogCheck']);
      $sql = "SELECT `Email` FROM `users` WHERE `Cookie`='$cookie'";
      $result = $conn->query($sql);
      if($result == true && $cookie > 0){
          $row = $result->fetch_assoc();
          if(!is_null($row)){
            $email = $row['Email'];
          }
          else{
            session_start();
            $_SESSION = array();
            session_destroy();
            unset($_COOKIE['LogCheck']);
            setcookie('LogCheck',null, time()-(60*60*24));
            header("Location:login.php?status=showMsg");
          }
      }
    }
  }

  // Check if there any SESSION to validate login
  if(isset($_SESSION['email']) && is_null($email)){
    $email = $_SESSION['email'];
    $sql = "SELECT `Email` FROM `users` WHERE `Email`='$email'";
    $result = $conn->query($sql);
    if($result == true ){
      $row = $result->fetch_assoc();
      if(is_null($row['Email'])){
        $_SESSION = array();
        session_destroy();
        header("Location:login.php?status=showMsg");
      }
    }
  }
  // redirect to login page if there isn't any SESSION or Cookie
  else if(is_null($email)){
    header("Location:login.php?status=showMsg");
  }
  if(is_null($email)){
    header("Location:login.php?status=showMsg");
  }

  $_SESSION['email'] = $email;
  
  require_once "parts/header.php"; 
?>

<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Petek</title>
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" type="text/css"href="css/styles.css">
        <!-- <link rel="stylesheet" type="text/css"href="css/all.css"> -->
        <link rel="stylesheet" type="text/css"href="css/products.css">
        <link rel="icon" href="logo.png" type="image" sizes="16x16">
      </head>
    <body id="bod">
      <?php if(isset($_GET['status'])){?>
        <?php if($_GET['status'] === "success"){?>
          <div class="container">
            <div class="alert alert-success text-center" role="alert">
              Welcome <?=$email?> !
            </div>
          </div>
        <?php }?>
      <?php }?>
      <!-- Add Product Modal -->
      <div class="modal addp" tabindex="-1" role="dialog" id="exampleModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Add Product</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true" class="x">&times;</span>
              </button>
            </div>
            <form id="addProduct" class="form-group">
              <div class="modal-body">
                <div class="row">
                  <div class="col-6">
                    <label for="name"><b>Product Name</b></label>
                  </div>
                  <div class="col-6">
                      <input type="text" id="name" placeholder="Product Name" name="pname" class="form-control name" autocomplete="off" minlength="1" required>
                  </div>
                  <br><br>
                  <div class="col-6">
                    <label for="quantity"><b>Quantity </b><span class="opt">(Optional)</span></label>
                  </div>
                  <div class="col-6">
                    <input type="number" id="quantity" placeholder="Quantity" name="quantity" class="form-control">
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-success addproduct" id="addproduct" >Submit</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Done</button>
              </div>
          </form>
          </div>
        </div>
      </div>

      <!--  Create List Modal-->
      <div class="modal" tabindex="-1" role="dialog" id="createlistmodal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Select Product List to Create a Copy</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true" class="x">&times;</span>
              </button>
            </div>
            <form class="form-group">
              <div class="modal-body">
                <div class="row">
                  <div class="container text-center">
                    <button id="listsToCopy" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Select Product List
                    </button>
                    <div class="dropdown-menu" id="droplistcreate">
                                        
                    </div>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-success" id="createlistsuccess" >Create</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
              </div>
          </form>
          </div>
        </div>
      </div>

      <div class="modal remove" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Product Deletion</h5>
            </div>
            <div class="modal-body">
              <p class="mbody">You are about to delete - - from your list</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" id="pdelete">Delete</button>
              <button type="button" class="btn btn-secondary" id="pcancel">Cancel</button>
            </div>
          </div>
        </div>
      </div>


      <div class="container text-center">
        <h1 class="pagetitle">Products List</h1>
      </div>
      <div class="container text-right">
        <br>
        <div class="row justify-content-center">
          <div class="col-2">
            <label><b>Total Lists:</b> <span class="badge badge-secondary" id="total">{{ totallists }}</span></label>
          </div>
          <!-- <div class="col-1">
            <button id="total" class="btn btn-primary" disabled>0</button>
          </div> -->
        </div>
        <hr>
      </div>
      


        <br>
        <div class="container">
          <div class="row">
            <div class="col-4 col-md-2">
              <label for="createlist"><b>Current List</b> <span class="badge badge-secondary" id="current">{{ current }}</span></label>
            </div>
            <!-- <div class="col-2 col-md-1">
              <button id="current" class="btn btn-primary" disabled>0</button>
            </div> -->
            <div class="col-6 col-md-2">
              <button type="button" class="btn btn-primary" id="addproductbtn">
                Add Product
              </button>
            </div>
          </div>
          <div class="row" id="spinner">
            <div class="col-6 col-md-5"></div>
            <div class="spinner-border text-info" role="status">
              <span class="sr-only">Loading Tables...</span>
            </div>
            <label class="text-info"><b>Loading Tables..</b></label>
          </div>
        </div>
        <div class="container table-responsive" id="allLists">
          <br>
          <table class="table table-light table-striped table-hover shadow-lg" id="Table">
              <thead>
                <tr>
                  <th scope="col">Product Name</th>
                  <th scope="col">Quantity</th>
                  <th scope="col">Purchased</th>
                  <th ></th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="row in rows" v-bind:data-id="row.ID">
                  <td class="name" id="fname"> {{ row.Name }} </td>
                  <td class="quantity" id="quantity"> {{ row.Quantity }} </td>
                  <td class="purchase" id="purchase"> {{ row.Purchase1 }} </td>
                  <td v-html="row.Purchase2">
                  </td>
                </tr>
              </tbody>
          </table> 
        </div>
        <div class="container">
          <hr>
          <div class="row">
            <div class="col-7 col-md-4">
              <div class="btn-group">
                <button id="lists" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Select Purchase List
                </button>
                <div class="dropdown-menu" id="drop">
                                    
                </div>
              </div>
            </div>
            <br><br><br>
            <div class="col-4 col-md-8">
              <button type="button" id="createlist "class="btn btn-primary createlist" >Create List</button>
            </div>
            
            <br><br>
          </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
        <script src="./JS/all.js"> </script>
        <script src="http://code.jquery.com/ui/1.12.0/jquery-ui.js" ></script>
        <script src="./JS/head.js"> </script>

    </body>
    <?php require_once "parts/footer.php"; ?>

</html>