<?php
require_once('db.php');
$email = htmlspecialchars($_GET['email']);
$password = htmlspecialchars($_POST['password']);
$username = htmlspecialchars($_GET['user']);
$phone = htmlspecialchars($_GET['phone']);
if(is_null($email) || is_null($password)) header("Location:index.php?");
if($email === ""|| $password === "") header("Location:index.php?");

if($phone === "" && $username !== "")
    $sql = "INSERT INTO `users`( Email, Pass, `Username`) VALUES ('$email','$password','$username')";
if($username === "" && $phone !== "")
    $sql = "INSERT INTO `users`( Email, Pass, `Phone`) VALUES ('$email','$password','$phone')";
if($phone !== "" && $username !== "")
    $sql = "INSERT INTO `users`( Email, Pass, `Phone`, `Username`) VALUES ('$email','$password','$phone','$username')";
if($phone === "" && $username === "")
    $sql = "INSERT INTO `users`( Email, Pass) VALUES ('$email','$password')";

if ($conn->query($sql)===TRUE) {
    header("Location:login.php?status=registered");
}else {
   $conn->error;
}


// end of the file
$conn->close();