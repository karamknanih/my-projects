<?php
require_once('db.php');

$pass = "";
$email = "";

if(isset($_POST["email"]) && isset($_POST["password"])){
    $pass = htmlspecialchars($_POST["password"]);
    $email=htmlspecialchars($_POST['email']);
}

//$newarr = array($email => $pass);
//$sql = "SELECT `Email`,`Pass` FROM `users` WHERE `Email`='$email'";
$sql = "SELECT `Email`, `isVerified` FROM `users` WHERE `Email`='$email' AND `Pass`='$pass'";

$result = $conn->query($sql);
if($result == true){
    $row = $result->fetch_assoc();
    // if($row['Pass'] !== $newarr[$email])
    //     header("Location:login.php?status=loginfail");
}
else{
    header("Location:login.php?status=loginfail");
}

if(is_null($row))
    header("Location:login.php?status=loginfail&email=$email");
else{
    if(!$row['isVerified']){
        $body = "Hello<br>Enter to this link in order to verify your account:<br>http://localhost/PRJ_207416850_315989830/verify.php?email=$email";
        $subject = "Petek - Account Activation";
        return header("Location:sendEmail.php?email=$email&Body=$body&Subject=$subject");  
    } 

    session_start();
    $_SESSION['email'] = $email;
    $i = 1;
    do{
        $random = rand(1,999999999);
        $sql = "SELECT `Email` FROM `users` WHERE `Cookie`='$random'";
        $result = $conn->query($sql);
        if($result == true){
            $row = $result->fetch_assoc();
            if(is_null($row)){
                $i = 0;
            }
        }
    }
    while($i);

    $newarr = array($random => $email);

    if ($_POST['staylogged'] === 'on'){
        setcookie('LogCheck',$random, time()+(60*60*24));
        $sql = "UPDATE `users` SET `Cookie` = $random WHERE `Email`='$email'";
        // $sql = "UPDATE `users` SET `Cookie` = $random WHERE `Email`='$newarr[$random]'";
        $conn->query($sql);
    }
    header("Location:index.php?status=success");
}


// end of the file
$conn->close();