<?php 
    require_once "parts/header.php"; 

    require_once('db.php'); //SQL Connection

    if(isset($_GET['email'])) //re-write the email in email field if there any
        $email = htmlspecialchars($_GET['email']); 
    else {
        $email = "";
    }

    // Check if there any Cookie for automatically login
    if(isset($_COOKIE['LogCheck'])){
        if(!is_null($_COOKIE['LogCheck'])){
            $cookie = htmlspecialchars($_COOKIE['LogCheck']);
            $sql = "SELECT `Email` FROM `users` WHERE `Cookie`='$cookie'";
            $result = $conn->query($sql);
            if($result == true && $cookie > 0){
                $row = $result->fetch_assoc();
                if(!is_null($row)){
                    header("Location:index.php");
                }
                else{
                    unset($_COOKIE['LogCheck']);
                    setcookie('LogCheck',null, time()-(60*60*24));
                }
            }
        }
    }
    // Check if there any SESSION for automatically login
    if(isset($_SESSION['email'])){
        if(!is_null($_SESSION['email'])){
            header("Location:index.php");
        }
    }

?>

<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign-in</title>
        <link rel="stylesheet" type="text/css"href="css/styles.css">
        <!-- <link rel="stylesheet" type="text/css"href="css/all.css"> -->
        <link rel="stylesheet" type="text/css"href="css/register.css">
        
        <link rel="icon" href="logo.png" type="image" sizes="16x16">
    </head>
    <body onload="loading('<?=$email?>')">
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

        <div class="container">
    
            <div class="card mb-6 shadow-lg" style="max-width: 540px;">
                <div class="row no-gutters">
                    <div class="col-md-12">
                        <div class="card-body">
                            <form class="was-validated text-center" method="POST" action="logCheck.php">
                                <div class="container alertc">

                                </div>
                                <?php if(isset($_GET['status'])){?>
                                    <?php if($_GET['status'] === "registered"){?>
                                    <div class="container">
                                        <div class="alert alert-success text-center" role="alert">
                                            Your Account Has Been Successfully Registered
                                        </div>
                                    </div>
                                    <?php } else if($_GET['status'] === "loginfail"){?>
                                    <div class="container">
                                        <div class="alert alert-danger text-center" role="alert">
                                                Invalid Email / Password.
                                        </div>
                                    </div>
                                    <?php } else if($_GET['status'] === "notVerified"){?>
                                    <div class="container">
                                        <div class="alert alert-info text-center verificationalert" role="alert" >
                                                Please verify your account, an email has been sent to your email.
                                                if you did not receive an email within 5 minutes,
                                                <button type="button" class="btn btn-light" id="verifybtn" >Click here to send an email</button>
                                        </div>
                                    </div>
                                    <?php } else {?>
                                    <div class="container">
                                        <div class="alert alert-warning text-center" role="alert">
                                            <?php if($_GET['status'] === "loggedout"){?>
                                                You Have Logged Out.
                                            <?php } else {?>
                                                You Must Log In.
                                            <?php }?>
                                        </div>
                                    </div>
                                    <?php }?>
                                <?php }?>
                                <h1 class="text-center">Log-in</h1>
                                <br>
                                <div class="row">
                                    <div class="col-12">
                                        <input class="form-control" id="lemail" type="text" name="email" placeholder="Email" required pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z.-]+\.[a-zA-Z]+" value="<?=$email?>">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <input class="form-control" id="lpassword" type="password" name="password" placeholder="Password" required pattern=".{5,}$">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-7">
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" class="form-check-input" name="staylogged" id="staylogged"
                                                    value="on">
                                                Stay logged in
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <br>
                                        <div class="alert alert-danger" id="ralert" role="alert" hidden>
                                            Invalid Input
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-7">
                                        <a class="linkcs" href="#" id="forgotPassword">Forgot Password?</a>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-12">
                                        <input type="submit" class="btn btn-success loginbtn" value="Login">
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col"> 
                                        <p>New? <a class="linkcs" href="./register.php">Sign up</a>.</p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="JS/login.js"></script>
        <script src="./JS/head.js"> </script>
    </body>
    <?php require_once "parts/footer.php"; ?>
  </html>