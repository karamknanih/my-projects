<?php
    require_once('db.php');

    session_start();
    $email = $_SESSION['email'];
    $sql = "UPDATE `users` SET `Cookie` = -1 WHERE `Email`='$email'";
    $conn->query($sql);
    $_SESSION = array();
    session_destroy();

    unset($_COOKIE['LogCheck']);
    setcookie('LogCheck',null, time()-(60*60*24));
    header("Location: login.php?status=loggedout");
?>