<!doctype html>
<html lang="en">
    <footer>
        <div class="container">
            <hr>
            <div class="row">
                <div class="col-sm-12 col-4">
                    <img src="logo.png" class="img-fluid footerimg" id="logo" alt="Responsive image"/>
                </div>
                <div class="col-sm-12 col-8">
                    <p>Web Development - Project<br>© All Rights Reserved<p>
                    <p>ID 1 : 207416850<br>ID 2 : 315989830</p>
                </div>
            </div>
        </div>
    </footer>