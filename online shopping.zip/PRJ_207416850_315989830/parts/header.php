<?php
    $theme = "Light";
    if(isset($_COOKIE['Theme'])){
        if(!is_null($_COOKIE['Theme'])){
            $theme = htmlspecialchars($_COOKIE['Theme']);
        }
    }
?>
<!doctype html>
<html lang="en">  
<header class="bg-light ">
    <div class="container">
        <nav class="navbar fixed-top navbar-expand-lg navbar-light shadow-lg">
            <div class="container ">
                <a class="navbar-brand " href="index.php" id="headt">
                <img src="logo.png" width="30" height="30" class="d-inline-block align-top">
                PETEK
                </a>
                <button class="navbar-toggler " type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarNav">
                    <ul class="navbar-nav">
                        <?php if(!isset($email)):?>
                            <li class="nav-item">
                                <a class="nav-link nv" href="Login.php">Login</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nv" href="Register.php">Register</a>
                            </li>
                        <?php else:?>
                            <li class="nav-item">
                                <a class="nav-link nv" href="index.php">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nv" href="productlist.php">Products</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nv" href="allfamilies.php">All Families</a>
                            </li>
                            
                            <div class="familiess"></div>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?=$email?>
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="passwordchange.php">Change Password</a>
                                <div class="dropdown-divider" ></div>
                                <a class="dropdown-item" href="logout.php" style="color:red;">Logout</a>
                                </div>
                            </li>
                        <?php endif;?>
                    </ul>
                </div>
                <?php if($theme == 'Dark'):?>
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="theme" checked>
                        <label class="custom-control-label" for="theme">Dark Mode</label>
                    </div>
                <?php else: ?>
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="theme">
                        <label class="custom-control-label" for="theme">Dark Mode</label>
                    </div>
                <?php endif;?>
            </div>
        </nav>
    </div>
</header>
