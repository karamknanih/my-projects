<?php 
    require_once "parts/header.php";

    require_once('db.php');

    session_start();
    $email = null;

    // Check if there any Cookie for automatically login
    if(isset($_COOKIE['LogCheck'])){
        if(!is_null($_COOKIE['LogCheck'])){
          $cookie = htmlspecialchars($_COOKIE['LogCheck']);
          $sql = "SELECT `Email` FROM `users` WHERE `Cookie`='$cookie'";
          $result = $conn->query($sql);
            if($result == true && $cookie > 0){
                $row = $result->fetch_assoc();
                if(!is_null($row)){
                    header("Location:index.php");
                }
                else{
                    unset($_COOKIE['LogCheck']);
                    setcookie('LogCheck',null, time()-(60*60*24));
                }
            }
        }
    }

    if(isset($_SESSION['email']) && is_null($email)){
        header("Location:index.php");
    }
    if(!is_null($email)){
        header("Location:index.php");
    }
    //Check if there any email of POST method
    if(!isset($_POST['email'])){
        header("Location:register.php");
    }
    else if(is_null($_POST['email'])){
        header("Location:register.php");
    }
    $email = htmlspecialchars($_POST["email"]);
    $user = htmlspecialchars($_POST["user"]);
    $phone = htmlspecialchars($_POST["phone"]);

    require_once('db.php'); // Connection to DB in order to check if email exists
    $sql = "SELECT `Email` FROM `users` WHERE `Email`='$email'";
    $result = $conn->query($sql); 
    if($result == true){
        $row = $result->fetch_assoc();
        if(isset($row['Email']))
            if(!is_null($row['Email']))
                header("Location:register.php?email=$email&user=$user&phone=$phone&status=emailexists");
    }

?>

<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign-up</title>
        <link rel="stylesheet" type="text/css"href="css/styles.css">
        <!-- <link rel="stylesheet" type="text/css"href="css/all.css"> -->
        <link rel="stylesheet" type="text/css"href="css/register.css">
        <link rel="icon" href="logo.png" type="image" sizes="16x16">
    </head>
    <body >
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
        <div class="container">
            <div class="card mb-6 shadow-lg" style="max-width: 540px;">
                <div class="row no-gutters">
                    <div class="col-md-12">
                        <div class="card-body">
                            <form id="pass" class="was-validated text-center" action="insertuser.php?email=<?=$email?>&user=<?=$user?>&phone=<?=$phone?>" method="POST">
                                <h1 class="text-center">Enter Your Password</h1>
                                <br>
                                <div class="row">
                                    <div class="col-12">
                                        <input class="form-control password" type="password" id="password" placeholder="Enter Password" name="password" required pattern=".{5,}$">
                                        <div class="invalid-feedback">
                                            Password must have atleast 5 characters.
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <input class="form-control rpassword" type="password" id="rpassword" placeholder="Repeat Password" name="password" required pattern=".{5,}$">
                                        <div class="invalid-feedback">
                                            Password does not match.
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-success registerbtn" id="passbtn" >Submit</button>
                                    </div>
                                </div>
                                <br>
                                <a href="register.php">Cancel</a>

                            </form>
                            <div class="stages">
                                <span class="stage finish"></span>
                                <span class="stage active"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="JS/login.js"></script>
        <script src="./JS/head.js"> </script>
    </body>
    <?php require_once "parts/footer.php"; ?>

  </html>