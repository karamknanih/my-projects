<?php 
  require_once('db.php');

  session_start();
  $email = null;
  // Check if there any Cookie to validate login
  if(isset($_COOKIE['LogCheck'])){
    if(!is_null($_COOKIE['LogCheck'])){
      $cookie = htmlspecialchars($_COOKIE['LogCheck']);
      $sql = "SELECT `Email` FROM `users` WHERE `Cookie`='$cookie'";
      $result = $conn->query($sql);
      if($result == true && $cookie > 0){
          $row = $result->fetch_assoc();
          if(!is_null($row)){
            $email = $row['Email'];
          }
          else{
            session_start();
            $_SESSION = array();
            session_destroy();
            unset($_COOKIE['LogCheck']);
            setcookie('LogCheck',null, time()-(60*60*24));
            header("Location:login.php?status=showMsg");
          }
      }
    }
  }

  // Check if there any SESSION to validate login
  if(isset($_SESSION['email']) && is_null($email)){
    $email = $_SESSION['email'];
    $sql = "SELECT `Email` FROM `users` WHERE `Email`='$email'";
    $result = $conn->query($sql);
    if($result == true ){
      $row = $result->fetch_assoc();
      if(is_null($row['Email'])){
        $_SESSION = array();
        session_destroy();
        header("Location:login.php?status=showMsg");
      }
    }
  }
  // redirect to login page if there isn't any SESSION or Cookie
  else if(is_null($email)){
    header("Location:login.php?status=showMsg");
  }
  if(is_null($email)){
    header("Location:login.php?status=showMsg");            
  }

  $_SESSION['email'] = $email;
  
  require_once "parts/header.php"; 
?>

<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
    <head>
        <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Petek - Profile</title>
            <link rel="stylesheet" type="text/css"href="css/styles.css">
            <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
            <!-- <link rel="stylesheet" type="text/css"href="css/all.css"> -->
            <link rel="stylesheet" type="text/css"href="css/passwordchange.css">
            <link rel="icon" href="logo.png" type="image" sizes="16x16">
    </head>
    <body >
        <div class="container">
            <div class="row justify-content-center">
                <form method="POST" action="#">
                    <div class="card">
                        <div class="card-header text-center">
                            <h4>Change Password</h4>
                        </div>
                        <div class="card-body ">
                            <div class="alerts">
                                
                            </div>
                            <div class="form-group">
                                <div class="row justify-content-center">
                                    <div class="col-9">
                                        <label for="currentPassword">Current Password</label>
                                        <input type="password" class="form-control" id="currentPassword" required>
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <div class="col-9">
                                        <label for="newPassword">New Password</label>
                                        <input type="password" class="form-control" id="newPassword" required>
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <div class="col-9">
                                        <label for="repeatPassword">Repeat Password</label>
                                        <input type="password" class="form-control" id="repeatPassword" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-center">
                            <button type="submit" class="btn btn-outline-dark" id="changePW">Change Password</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="./JS/passwordchange.js"> </script>
        <script src="./JS/head.js"> </script>

    </body>

<?php require_once "parts/footer.php"; ?>

</html>