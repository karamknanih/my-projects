<?php 
  require_once('db.php');
  session_start();
  $email = null;
  // Check if there any Cookie to validate login
  if(isset($_COOKIE['LogCheck'])){
    if(!is_null($_COOKIE['LogCheck'])){
      $cookie = htmlspecialchars($_COOKIE['LogCheck']);
      $sql = "SELECT `Email` FROM `users` WHERE `Cookie`='$cookie'";
      $result = $conn->query($sql);
      if($result == true && $cookie > 0){
          $row = $result->fetch_assoc();
          if(!is_null($row)){
            $email = $row['Email'];
          }
          else{
            session_start();
            $_SESSION = array();
            session_destroy();
            unset($_COOKIE['LogCheck']);
            setcookie('LogCheck',null, time()-(60*60*24));
            header("Location:login.php?status=showMsg");
          }
      }
    }
  }

  // Check if there any SESSION to validate login
  if(isset($_SESSION['email']) && is_null($email)){
    $email = $_SESSION['email'];
    $sql = "SELECT `Email` FROM `users` WHERE `Email`='$email'";
    $result = $conn->query($sql);
    if($result == true ){
      $row = $result->fetch_assoc();
      if(is_null($row['Email'])){
        $_SESSION = array();
        session_destroy();
        header("Location:login.php?status=showMsg");
      }
    }
  }
  // redirect to login page if there isn't any SESSION or Cookie
  else if(is_null($email)){
    header("Location:login.php?status=showMsg");
  }
  if(is_null($email)){
    header("Location:login.php?status=showMsg");
  }

  $_SESSION['email'] = $email;

  require_once "parts/header.php"; 
?>

<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Petek - Family</title>
        <link rel="stylesheet" type="text/css"href="css/styles.css">
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <!-- <link rel="stylesheet" type="text/css"href="css/all.css"> -->
        <link rel="stylesheet" type="text/css"href="css/family.css">
        <link rel="icon" href="logo.png" type="image" sizes="16x16">
    </head>
    <body >
        <div class="modal remove" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Product Deletion</h5>
                </div>
                <div class="modal-body">
                  <p class="mrbody">You are about to delete - - from your list</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" id="pdelete">Delete</button>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
              </div>
            </div>
        </div>

        <div class="modal edit" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Product Deletion</h5>
                </div>
                <form>
                    <div class="modal-body">
                    <p class="mebody">You are about to edit product: </p>
                    <div class="form-group">
                        <label for="productname">Enter New Name:</label>
                        <input type="text" class="form-control" id="productname" placeholder="Product New Name">
                    </div>
                    </div>
                    <div class="modal-footer">
                    <button type="submit" class="btn btn-warning" id="editbtn">Submit Edit</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    </div>
                </form>
              </div>
            </div>
        </div>
        
        <div class="container">
            <h2 class="text-center">Product Lists</h2>
            <div class="text-center">
                <small><b>This is a list of your bought products</b></small>
            </div>
            <hr>
          <div class="container table-responsive">
            <table class="table table-light table-striped table-hover shadow-lg products">
                <thead>
                    <tr>
                      <th scope="col">Product Name</th>
                      <th scope="col">List Number</th>
                      <th scope="col">Quantity</th>
                      <th scope="col"></th>
                    </tr>
                  </thead>
                <tbody>

                </tbody>
            </table>
          </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
        <script src="./JS/productlist.js"> </script>
        <script src="./JS/head.js"> </script>
    </body>
    
    <?php require_once "parts/footer.php"; ?>
</html>