<?php 
    require_once "parts/header.php";

    require_once('db.php');

    session_start();
    $email = null;
    // Check if there any Cookie for automatically login
    if(isset($_COOKIE['LogCheck'])){
        if(!is_null($_COOKIE['LogCheck'])){
            $cookie = htmlspecialchars($_COOKIE['LogCheck']);
            $sql = "SELECT `Email` FROM `users` WHERE `Cookie`='$cookie'";
            $result = $conn->query($sql);
            if($result == true && $cookie > 0){
                $row = $result->fetch_assoc();
                if(!is_null($row)){
                    header("Location:index.php");
                }
                else{
                    unset($_COOKIE['LogCheck']);
                    setcookie('LogCheck',null, time()-(60*60*24));
                }
            }
        }
    }

    if(isset($_SESSION['email']) && is_null($email)){
        header("Location:index.php");
    }
    if(!is_null($email)){
        header("Location:index.php");
    }
    if(isset($_GET['status']) == "emailexists"){
        $email = htmlspecialchars($_GET['email']);
        $user = htmlspecialchars($_GET['user']);
        $phone = htmlspecialchars($_GET['phone']);
    }else{
        $phone = null;
        $user = null;
    }
?>

<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign-up</title>
        <link rel="stylesheet" type="text/css"href="css/styles.css">
        <!-- <link rel="stylesheet" type="text/css"href="css/all.css"> -->
        <link rel="stylesheet" type="text/css"href="css/register.css">
        <link rel="icon" href="logo.png" type="image" sizes="16x16">
    </head>
    <body >
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <div class="container">
            <div class="card mb-6 shadow-lg" style="max-width: 540px;">
                <div class="row no-gutters">
                    <div class="col-md-12">
                        <div class="card-body">
                            <form action="./password.php" class="was-validated text-center" method="POST">
                                <h1 class="text-center">Register</h1>
                                <?php if(isset($_GET['status'])){?>
                                    <?php if($_GET['status'] === "emailexists"){?>
                                        <div class="row">
                                            <div class="col-12">
                                                <br>
                                                <div class="alert alert-danger" id="realert" role="alert" <?php if(!isset($_GET['status']) == "emailexists"){?>hidden <?php }?>>
                                                    Email Exists
                                                </div>
                                            </div>
                                        </div>
                                    <?php }?>
                                <?php }?>
                                <div class="row">
                                    <div class="col-12">
                                        <br>
                                        <div class="alert alert-danger" id="ralert" role="alert" hidden>
                                            Invalid Input
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <input class="form-control" type="text" id="email" placeholder="Enter Email" name="email" required pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z.-]+\.[a-zA-Z]+" value="<?=$email?>">
                                        <div class="invalid-feedback">
                                            Invalid Email.
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <input class="form-control" type="text" id="remail" placeholder="Repeat Email" name="email" required pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z.-]+\.[a-zA-Z]+">
                                        <div class="invalid-feedback">
                                            Email does not match.
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <input class="form-control" type="text" id="user" placeholder="Username" name="user" value="<?=$user?>">
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-12">
                                        <input class="form-control" type="tel" id="phone" placeholder="Phone Number" name="phone" pattern="[0]{1}[5]{1}[0-9]{8}" value="<?=$phone?>">
                                        <div class="invalid-feedback">
                                            Format: 05XXXXXXXXXXX   -  X is a number
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class=col-12>
                                        <button type="submit" class="btn btn-success registerbtn" id="registerbtn">Next</button>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col signin">
                                        <p>Already have an account? <a class="linkcs" href="./login.php">Sign in</a>.</p>
                                    </div>
                                </div>
                            </form>
                            <div class="stages">
                                <span class="stage active"></span>
                                <span class="stage"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="JS/login.js"></script>
        <script src="./JS/head.js"> </script>
        <script>
        $(document).ready(function (){
            $('#email').focus();
        });
        </script>
    </body>
    <?php require_once "parts/footer.php"; ?>

  </html>