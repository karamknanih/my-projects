<?php 
    require_once('db.php');

    $email = null;
    $reset = null;
    $newPass = null;
    
    if(isset($_GET['Email'])){
        if(!is_null($_GET['Email'])){
            $email = htmlspecialchars($_GET['Email']);
        }
    }

    if(isset($_GET['Reset'])){
        if(!is_null($_GET['Reset'])){
            $reset = htmlspecialchars($_GET['Reset']);
        }
    }

    if(isset($_POST['newPassword'])){
        if(!is_null($_POST['newPassword'])){
            $newPass = htmlspecialchars($_POST['newPassword']);
        }
    }


    if(is_null($email) || is_null($reset) || is_null($newPass)) header("Location:login.php?status=resetfail");



    $sql = "UPDATE `users` SET `Pass` = $newPass, `resetpw` = NULL WHERE `Email` = '$email' and `resetpw` = $reset";

    if ($conn->query($sql)===TRUE) {
        echo json_encode($conn->insert_id);
    }else {
        echo json_encode($conn->error);
    }

    header("Location:login.php?status=resetsuccess");
    $conn->close();

?>
