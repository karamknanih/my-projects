<?php 
    require_once('db.php');

    $email = null;
    $reset = null;

    if(isset($_GET['Email'])){
        if(!is_null($_GET['Email'])){
            $email = htmlspecialchars($_GET['Email']);
        }
    }

    if(isset($_GET['Reset'])){
        if(!is_null($_GET['Reset'])){
            $reset = htmlspecialchars($_GET['Reset']);
        }
    }

    if(is_null($email) || is_null($reset)) header("Location:login.php");
    if($reset == "") header("Location:login.php");

    $sql = "SELECT `Email` FROM `users` WHERE `Email` =  '$email' AND `resetpw` = $reset";

    $result = $conn->query($sql);
    $row = null;

    $lists = array();
    while($row = $result->fetch_assoc()){
        $lists[] = $row;
    }
    if(isset($lists[0]['Email'])){
        if(is_null($lists[0]['Email']))
            header("Location:login.php");
    }
    else{
        header("Location:login.php");
    }


    require_once "parts/header.php"; 
?>

<!DOCTYPE html>
<html lang="en" data-theme="<?=$theme?>">
    <head>
        <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Petek - Profile</title>
            <link rel="stylesheet" type="text/css"href="css/styles.css">
            <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
            <!-- <link rel="stylesheet" type="text/css"href="css/all.css"> -->
            <link rel="stylesheet" type="text/css"href="css/passwordchange.css">
            <link rel="icon" href="logo.png" type="image" sizes="16x16">
    </head>
    <body >
        <div class="container">
            <div class="row justify-content-center">
                <form method="POST" action="reset.php?Email=<?=$email?>&Reset=<?=$reset?>">
                    <div class="card" style="width: 30rem;">
                        <div class="card-header text-center">
                            <h4>Change Password</h4>
                        </div>
                        <div class="card-body ">
                            <div class="alerts">
                                
                            </div>
                            <div class="form-group">
                                <div class="row justify-content-center">
                                    <div class="col-9">
                                        <label for="newPassword">New Password</label>
                                        <input type="password" class="form-control" name="newPassword" id="newPassword" required>
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <div class="col-9">
                                        <label for="repeatPassword">Repeat Password</label>
                                        <input type="password" class="form-control" id="repeatPassword" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-center">
                            <button type="submit" class="btn btn-dark" id="resetPW">Change Password</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="./JS/passwordchange.js"> </script>
        <script src="./JS/head.js"> </script>

    </body>

<?php require_once "parts/footer.php"; ?>

</html>