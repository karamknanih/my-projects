<?php
    use PHPMailer\PHPMailer\PHPMailer;

    if (true) {
        if($_GET['email'] == null){
            if($_POST['Email'] != null){
                $ToEmail = htmlspecialchars($_POST['Email']);
            }else{
                header("Location:login.php");
            }
        }else{
            $ToEmail = htmlspecialchars($_GET['email']);
        }
        
        // $ToEmail  = htmlspecialchars($_GET['email']) == null ? htmlspecialchars($_POST['Email']) : header("Location:login.php");
        $name = "Petek";
        $email = "petekweb2020@gmail.com";
        $subject =$_GET['Subject'] == null ? $_POST['Subject'] : header("Location:login.php");
        $body = $_GET['Body'] == null ? $_POST['Body'] : header("Location:login.php");


        require_once "PHPMailer/PHPMailer.php";
        require_once "PHPMailer/SMTP.php";
        require_once "PHPMailer/Exception.php";

        $mail = new PHPMailer();

        //SMTP Settings
        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        $mail->Username = "petekweb2020@gmail.com";
        $mail->Password = 'webcourse2020';
        $mail->Port = 465; //587
        $mail->SMTPSecure = "ssl"; //tls

        //Email Settings
        $mail->isHTML(true);
        $mail->setFrom($email, $name);
        $mail->addAddress($ToEmail);
        $mail->Subject = $subject;
        $mail->Body = $body;

        if ($mail->send()) {
            $status = "success";
            $response = "Email is sent!";
            if(isset($_GET['Body']))
                header("Location:login.php?status=notVerified&email=$ToEmail");
        } else {
            $status = "failed";
            $response = "Something is wrong: <br><br>" . $mail->ErrorInfo;
            if(isset($_GET['Body']))
                header("Location:login.php?status=notVerified&email=$ToEmail");
        }

        exit(json_encode(array("status" => $status, "response" => $response)));
    }
?>
