<?php 
    $themeName = htmlspecialchars($_POST['Theme']);
    setcookie('Theme',$themeName, time()+(60*60*24));
?>