<?php require("db.php");?>
<?php 
header('Content-Type: application/json');
session_start();
$email = $_GET['email'];
$sql = "SELECT `isVerified` FROM `Users` WHERE `Email` = '$email'";

$result = $conn->query($sql);
while($row = $result->fetch_assoc()){
    if(!is_null($row['isVerified'])){
        if($row['isVerified']) header("Location:index.php");
    }
}

$sql = "UPDATE `Users` SET `isVerified` = 1 WHERE `Email` = '$email'";

if ($conn->query($sql)===TRUE) {
    echo json_encode($conn->insert_id);
    header("Location:index.php?verified=true");
}else {
    echo json_encode($conn->error);
}

$conn->close();