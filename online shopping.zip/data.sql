SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


INSERT INTO `users` (`Email`, `Pass`, `Username`, `Phone`, `cookie`, `isVerified`) VALUES
('test10@gmail.com', '123456', NULL, NULL, -1, 1),
('test1@gmail.com', '123456', NULL, NULL, -1, 1),
('test2@gmail.com', '123456', NULL, NULL, -1, 0),
('test3@gmail.com', '123456', NULL, NULL, -1, 1),
('test4@gmail.com', '123456', NULL, NULL, -1, 1),
('test5@gmail.com', '123456', NULL, NULL, -1, 1),
('test6@gmail.com', '123456', NULL, NULL, -1, 1),
('test7@gmail.com', '123456', NULL, NULL, -1, 1),
('test8@gmail.com', '123456', NULL, NULL, -1, 1),
('test9@gmail.com', '123456', NULL, NULL, -1, 1);


INSERT INTO `family` (`FamilyID`, `FamilyName`, `Description`, `CreationDate`, `ManagerEmail`) VALUES
(1, 'Johnson', 'We are the best', '2020-08-01 18:48:55', 'test1@gmail.com'),
(2, 'The Gellers', '', '2020-06-11 18:49:16', 'test1@gmail.com'),
(4, 'Green', '', '2020-08-23 19:01:45', 'test3@gmail.com'),
(5, 'testers', '', '2020-08-23 19:02:11', 'test3@gmail.com');


INSERT INTO `allproducts` (`ID`, `Name`, `Quantity`, `IsPurchased`) VALUES
(1, 'Milk', 1, 1),
(2, 'Bread', 10, 1),
(3, 'Yogurt', 0, 0),
(4, 'Water', 6, 0),
(5, 'Milk', 1, 1),
(6, 'Water', 6, 0),
(7, 'Bread', 10, 1),
(8, 'Yogurt', 0, 0),
(9, 'Apple', 10, 1),
(10, 'Peach', 10, 0),
(11, 'Pear', 20, 0),
(12, 'Beer', 5, 1),
(13, 'Milk', 0, 0),
(19, 'test', 0, 0),
(20, 'Milk', 0, 0),
(21, 'Bread', 0, 1),
(23, 'Bread', 0, 1),
(24, 'Fish', 0, 0),
(27, 'Water', 0, 1);


INSERT INTO `applications` (`ApplicantEmail`, `FamilyID`) VALUES
('test3@gmail.com', 1),
('test5@gmail.com', 1),
('test5@gmail.com', 2),
('test7@gmail.com', 1),
('test8@gmail.com', 1);


INSERT INTO `familyproducts` (`FamilyID`, `ProductID`) VALUES
(4, 19),
(1, 20),
(1, 21),
(5, 23),
(2, 24);


INSERT INTO `userlists` (`UserEmail`, `ListID`) VALUES
('test1@gmail.com', 1),
('test1@gmail.com', 2),
('test3@gmail.com', 1);


INSERT INTO `productlist` (`ProductID`, `ListID`, `UserEmail`) VALUES
(1, 1, 'test1@gmail.com'),
(2, 1, 'test1@gmail.com'),
(3, 1, 'test1@gmail.com'),
(4, 1, 'test1@gmail.com'),
(5, 2, 'test1@gmail.com'),
(6, 2, 'test1@gmail.com'),
(7, 2, 'test1@gmail.com'),
(8, 2, 'test1@gmail.com'),
(9, 2, 'test1@gmail.com'),
(10, 2, 'test1@gmail.com'),
(11, 2, 'test1@gmail.com'),
(12, 2, 'test1@gmail.com'),
(27, 1, 'test3@gmail.com');


INSERT INTO `familymembers` (`MemberEmail`, `FamilyID`, `JoinDate`) VALUES
('test10@gmail.com', 2, '2020-07-16 18:55:51'),
('test1@gmail.com', 5, '2020-08-23 19:06:58'),
('test4@gmail.com', 1, '2020-08-22 18:58:47'),
('test4@gmail.com', 2, '2020-07-17 18:55:54'),
('test6@gmail.com', 1, '2020-08-23 18:55:33'),
('test6@gmail.com', 2, '2020-08-12 18:57:36'),
('test9@gmail.com', 1, '2020-08-23 18:55:34'),
('test9@gmail.com', 2, '2020-07-11 18:55:52');


UPDATE `familymembers` SET `JoinDate` = '2020-08-01 18:48:55' WHERE `MemberEmail` = 'test1@gmail.com' AND `FamilyID` = 1;
UPDATE `familymembers` SET `JoinDate` = '2020-06-11 18:58:01' WHERE `MemberEmail` = 'test1@gmail.com' AND `FamilyID` = 2;
UPDATE `familymembers` SET `JoinDate` = '2020-08-23 19:01:45' WHERE `MemberEmail` = 'test3@gmail.com' AND `FamilyID` = 4;
UPDATE `familymembers` SET `JoinDate` = '2020-08-23 19:02:11' WHERE `MemberEmail` = 'test3@gmail.com' AND `FamilyID` = 5;


COMMIT;
