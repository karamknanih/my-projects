-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2020 at 04:27 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prj_207416850_315989830`
--
CREATE DATABASE IF NOT EXISTS `prj_207416850_315989830` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `prj_207416850_315989830`;

-- --------------------------------------------------------

--
-- Table structure for table `allproducts`
--

DROP TABLE IF EXISTS `allproducts`;
CREATE TABLE IF NOT EXISTS `allproducts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `IsPurchased` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `allproducts`:
--

--
-- Dumping data for table `allproducts`
--

INSERT INTO `allproducts` (`ID`, `Name`, `Quantity`, `IsPurchased`) VALUES
(1, 'Milk', 1, 1),
(2, 'Bread', 10, 1),
(3, 'Yogurt', 0, 0),
(4, 'Water', 6, 0),
(5, 'Milk', 1, 1),
(6, 'Water', 6, 0),
(7, 'Bread', 10, 1),
(8, 'Yogurt', 0, 0),
(9, 'Apple', 10, 1),
(10, 'Peach', 10, 0),
(11, 'Pear', 20, 0),
(12, 'Beer', 5, 1),
(13, 'Milk', 0, 0),
(19, 'test', 0, 0),
(20, 'Milk', 0, 0),
(21, 'Bread', 0, 1),
(23, 'Bread', 0, 1),
(24, 'Fish', 0, 0),
(27, 'Water', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
CREATE TABLE IF NOT EXISTS `applications` (
  `ApplicantEmail` varchar(255) NOT NULL,
  `FamilyID` int(11) NOT NULL,
  PRIMARY KEY (`ApplicantEmail`,`FamilyID`),
  KEY `FK_Apply` (`FamilyID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `applications`:
--   `FamilyID`
--       `family` -> `FamilyID`
--   `ApplicantEmail`
--       `users` -> `Email`
--

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`ApplicantEmail`, `FamilyID`) VALUES
('test3@gmail.com', 1),
('test5@gmail.com', 1),
('test5@gmail.com', 2),
('test7@gmail.com', 1),
('test8@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

DROP TABLE IF EXISTS `family`;
CREATE TABLE IF NOT EXISTS `family` (
  `FamilyID` int(11) NOT NULL AUTO_INCREMENT,
  `FamilyName` varchar(255) NOT NULL,
  `Description` varchar(2000) NOT NULL,
  `CreationDate` datetime NOT NULL DEFAULT current_timestamp(),
  `ManagerEmail` varchar(255) NOT NULL,
  PRIMARY KEY (`FamilyID`),
  KEY `FK_ManagerFamily` (`ManagerEmail`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `family`:
--   `ManagerEmail`
--       `users` -> `Email`
--

--
-- Dumping data for table `family`
--

INSERT INTO `family` (`FamilyID`, `FamilyName`, `Description`, `CreationDate`, `ManagerEmail`) VALUES
(1, 'Johnson', 'We are the best', '2020-08-01 18:48:55', 'test1@gmail.com'),
(2, 'The Gellers', '', '2020-06-11 18:49:16', 'test1@gmail.com'),
(4, 'Green', '', '2020-08-23 19:01:45', 'test3@gmail.com'),
(5, 'testers', '', '2020-08-23 19:02:11', 'test3@gmail.com');

--
-- Triggers `family`
--
DROP TRIGGER IF EXISTS `OnCreate`;
DELIMITER $$
CREATE TRIGGER `OnCreate` AFTER INSERT ON `family` FOR EACH ROW INSERT INTO `familymembers` ( `MemberEmail`, `FamilyID` )  VALUES (NEW.ManagerEmail, NEW.FamilyID)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `familymembers`
--

DROP TABLE IF EXISTS `familymembers`;
CREATE TABLE IF NOT EXISTS `familymembers` (
  `MemberEmail` varchar(255) NOT NULL,
  `FamilyID` int(11) NOT NULL,
  `JoinDate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`MemberEmail`,`FamilyID`),
  KEY `FK_Member` (`FamilyID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `familymembers`:
--   `MemberEmail`
--       `users` -> `Email`
--   `FamilyID`
--       `family` -> `FamilyID`
--

--
-- Dumping data for table `familymembers`
--

INSERT INTO `familymembers` (`MemberEmail`, `FamilyID`, `JoinDate`) VALUES
('test10@gmail.com', 2, '2020-07-16 18:55:51'),
('test1@gmail.com', 1, '2020-08-01 18:48:55'),
('test1@gmail.com', 2, '2020-06-11 18:58:01'),
('test1@gmail.com', 5, '2020-08-23 19:06:58'),
('test3@gmail.com', 4, '2020-08-23 19:01:45'),
('test3@gmail.com', 5, '2020-08-23 19:02:11'),
('test4@gmail.com', 1, '2020-08-22 18:58:47'),
('test4@gmail.com', 2, '2020-07-17 18:55:54'),
('test6@gmail.com', 1, '2020-08-23 18:55:33'),
('test6@gmail.com', 2, '2020-08-12 18:57:36'),
('test9@gmail.com', 1, '2020-08-23 18:55:34'),
('test9@gmail.com', 2, '2020-07-11 18:55:52');

-- --------------------------------------------------------

--
-- Table structure for table `familyproducts`
--

DROP TABLE IF EXISTS `familyproducts`;
CREATE TABLE IF NOT EXISTS `familyproducts` (
  `FamilyID` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  PRIMARY KEY (`ProductID`,`FamilyID`),
  KEY `FK_FamilyProduct` (`FamilyID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `familyproducts`:
--   `FamilyID`
--       `family` -> `FamilyID`
--   `ProductID`
--       `allproducts` -> `ID`
--

--
-- Dumping data for table `familyproducts`
--

INSERT INTO `familyproducts` (`FamilyID`, `ProductID`) VALUES
(4, 19),
(1, 20),
(1, 21),
(5, 23),
(2, 24);

-- --------------------------------------------------------

--
-- Table structure for table `productlist`
--

DROP TABLE IF EXISTS `productlist`;
CREATE TABLE IF NOT EXISTS `productlist` (
  `ProductID` int(11) NOT NULL,
  `ListID` int(11) NOT NULL,
  `UserEmail` varchar(255) NOT NULL,
  PRIMARY KEY (`UserEmail`,`ListID`,`ProductID`),
  KEY `FK_UserProducts2` (`ProductID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `productlist`:
--   `UserEmail`
--       `userlists` -> `UserEmail`
--   `ListID`
--       `userlists` -> `ListID`
--   `ProductID`
--       `allproducts` -> `ID`
--

--
-- Dumping data for table `productlist`
--

INSERT INTO `productlist` (`ProductID`, `ListID`, `UserEmail`) VALUES
(1, 1, 'test1@gmail.com'),
(2, 1, 'test1@gmail.com'),
(3, 1, 'test1@gmail.com'),
(4, 1, 'test1@gmail.com'),
(5, 2, 'test1@gmail.com'),
(6, 2, 'test1@gmail.com'),
(7, 2, 'test1@gmail.com'),
(8, 2, 'test1@gmail.com'),
(9, 2, 'test1@gmail.com'),
(10, 2, 'test1@gmail.com'),
(11, 2, 'test1@gmail.com'),
(12, 2, 'test1@gmail.com'),
(27, 1, 'test3@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `userlists`
--

DROP TABLE IF EXISTS `userlists`;
CREATE TABLE IF NOT EXISTS `userlists` (
  `UserEmail` varchar(255) NOT NULL,
  `ListID` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`UserEmail`,`ListID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `userlists`:
--   `UserEmail`
--       `users` -> `Email`
--

--
-- Dumping data for table `userlists`
--

INSERT INTO `userlists` (`UserEmail`, `ListID`) VALUES
('test1@gmail.com', 1),
('test1@gmail.com', 2),
('test3@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `Email` varchar(255) NOT NULL,
  `Pass` varchar(255) NOT NULL,
  `Username` varchar(255) DEFAULT NULL,
  `Phone` varchar(10) DEFAULT NULL,
  `cookie` int(10) NOT NULL,
  `resetpw` int(6) NOT NULL,
  `isVerified` int(1) DEFAULT 0,
  PRIMARY KEY (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `users`:
--

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Email`, `Pass`, `Username`, `Phone`, `cookie`, `resetpw`, `isVerified`) VALUES
('test10@gmail.com', '123456', NULL, NULL, -1, 0, 1),
('test1@gmail.com', '123456', NULL, NULL, -1, 0, 1),
('test2@gmail.com', '123456', NULL, NULL, -1, 0, 0),
('test3@gmail.com', '123456', NULL, NULL, -1, 0, 1),
('test4@gmail.com', '123456', NULL, NULL, -1, 0, 1),
('test5@gmail.com', '123456', NULL, NULL, -1, 0, 1),
('test6@gmail.com', '123456', NULL, NULL, -1, 0, 1),
('test7@gmail.com', '123456', NULL, NULL, -1, 0, 1),
('test8@gmail.com', '123456', NULL, NULL, -1, 0, 1),
('test9@gmail.com', '123456', NULL, NULL, -1, 0, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `applications`
--
ALTER TABLE `applications`
  ADD CONSTRAINT `FK_Apply` FOREIGN KEY (`FamilyID`) REFERENCES `family` (`FamilyID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_EmailApply` FOREIGN KEY (`ApplicantEmail`) REFERENCES `users` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `family`
--
ALTER TABLE `family`
  ADD CONSTRAINT `FK_ManagerFamily` FOREIGN KEY (`ManagerEmail`) REFERENCES `users` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `familymembers`
--
ALTER TABLE `familymembers`
  ADD CONSTRAINT `FK_Familyy` FOREIGN KEY (`MemberEmail`) REFERENCES `users` (`Email`),
  ADD CONSTRAINT `FK_Member` FOREIGN KEY (`FamilyID`) REFERENCES `family` (`FamilyID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `familyproducts`
--
ALTER TABLE `familyproducts`
  ADD CONSTRAINT `FK_FamilyProduct` FOREIGN KEY (`FamilyID`) REFERENCES `family` (`FamilyID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_FamilyProduct2` FOREIGN KEY (`ProductID`) REFERENCES `allproducts` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `productlist`
--
ALTER TABLE `productlist`
  ADD CONSTRAINT `FK_UserProducts` FOREIGN KEY (`UserEmail`,`ListID`) REFERENCES `userlists` (`UserEmail`, `ListID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_UserProducts2` FOREIGN KEY (`ProductID`) REFERENCES `allproducts` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `userlists`
--
ALTER TABLE `userlists`
  ADD CONSTRAINT `FK_UserEmail1` FOREIGN KEY (`UserEmail`) REFERENCES `users` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
